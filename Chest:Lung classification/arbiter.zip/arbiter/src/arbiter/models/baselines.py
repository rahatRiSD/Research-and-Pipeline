"""Comparison models.

All baselines share the backbone factory and the same input pipeline, so the
tables isolate the *method*, not the encoder or the preprocessing.

  SingleStream        raw image only (ResNet50 / DenseNet121 / EfficientNet-B0 /
                      ConvNeXt-T / ViT-S depending on config)
  AnatomyStream       anatomy-guided composite only
  AlwaysOnDual        both streams + cross-attention on every case (PelFANet-style)
  SecondOpinion       binary correctness gate over a dual-stream network
                      (reimplementation of the prior state of the art)
"""
from __future__ import annotations

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from .arbiter_net import CrossAttentionFusion
from .backbones import create_backbone


class SingleStream(nn.Module):
    """Standard classifier; `stream` selects which input it consumes."""

    def __init__(self, num_classes: int, backbone: str = "resnet50", pretrained: bool = True,
                 stream: str = "a", dropout: float = 0.2):
        super().__init__()
        self.backbone = create_backbone(backbone, pretrained, in_chans=3)
        self.head = nn.Sequential(nn.Dropout(dropout), nn.Linear(self.backbone.num_features, num_classes))
        self.stream = stream

    def forward(self, x_a: torch.Tensor, x_b: torch.Tensor, mask: torch.Tensor, **_) -> Dict[str, torch.Tensor]:
        x = x_a if self.stream == "a" else x_b
        feat, pooled = self.backbone(x)
        return {"logits": self.head(pooled), "feat": feat, "pooled": pooled}


class AlwaysOnDual(nn.Module):
    """Unconditional dual-stream with cross-attention fusion (upper bound on cost)."""

    def __init__(self, num_classes: int, backbone: str = "efficientnet_b0", pretrained: bool = True,
                 fusion_dim: int = 256, heads: int = 4, dropout: float = 0.2):
        super().__init__()
        self.backbone_a = create_backbone(backbone, pretrained, 3)
        self.backbone_b = create_backbone(backbone, pretrained, 3)
        da, db = self.backbone_a.num_features, self.backbone_b.num_features
        self.fusion = CrossAttentionFusion(da, db, fusion_dim, heads)
        self.head = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(fusion_dim + da + db, 512),
            nn.GELU(),
            nn.Linear(512, num_classes),
        )

    def forward(self, x_a: torch.Tensor, x_b: torch.Tensor, mask: torch.Tensor, **_) -> Dict[str, torch.Tensor]:
        fa, ha = self.backbone_a(x_a)
        fb, hb = self.backbone_b(x_b)
        fused = self.fusion(fa, fb)
        logits = self.head(torch.cat([fused, ha, hb], dim=1))
        return {"logits": logits, "feat": fa, "pooled": ha, "fused": fused}


class SecondOpinion(nn.Module):
    """Prior SOTA: binary correctness gate, fixed 0.5 threshold, two streams."""

    def __init__(self, num_classes: int, backbone: str = "efficientnet_b0", pretrained: bool = True,
                 fusion_dim: int = 256, heads: int = 1, dropout: float = 0.2, threshold: float = 0.5):
        super().__init__()
        self.backbone_a = create_backbone(backbone, pretrained, 3)
        self.backbone_b = create_backbone(backbone, pretrained, 3)
        da, db = self.backbone_a.num_features, self.backbone_b.num_features
        self.head_a = nn.Sequential(nn.Dropout(dropout), nn.Linear(da, num_classes))
        self.fusion = CrossAttentionFusion(da, db, fusion_dim, heads)
        self.head_fused = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(fusion_dim + da + db, 512),
            nn.GELU(),
            nn.Linear(512, num_classes),
        )
        self.gate = nn.Sequential(
            nn.Linear(da + num_classes + 1, 256),
            nn.ReLU(inplace=True),
            nn.Linear(256, 1),
        )
        self.threshold = threshold
        self.num_classes = num_classes

    def _gate_alpha(self, ha: torch.Tensor, za: torch.Tensor) -> torch.Tensor:
        p = za.softmax(dim=1)
        ent = -(p * (p + 1e-8).log()).sum(dim=1, keepdim=True)
        return torch.sigmoid(self.gate(torch.cat([ha, p, ent], dim=1))).squeeze(1)

    def forward(self, x_a: torch.Tensor, x_b: torch.Tensor, mask: torch.Tensor, **_) -> Dict[str, torch.Tensor]:
        fa, ha = self.backbone_a(x_a)
        za = self.head_a(ha)
        fb, hb = self.backbone_b(x_b)
        fused = self.fusion(fa, fb)
        zf = self.head_fused(torch.cat([fused, ha, hb], dim=1))
        alpha = self._gate_alpha(ha, za)
        z_soft = alpha.unsqueeze(1) * za + (1 - alpha).unsqueeze(1) * zf
        return {"logits": z_soft, "z_a": za, "z_fused": zf, "alpha": alpha,
                "feat": fa, "pooled": ha}

    @torch.no_grad()
    def infer(self, x_a: torch.Tensor, x_b: torch.Tensor, mask: torch.Tensor, **_) -> Dict[str, torch.Tensor]:
        fa, ha = self.backbone_a(x_a)
        za = self.head_a(ha)
        alpha = self._gate_alpha(ha, za)
        logits = za.clone()
        level = torch.ones(x_a.shape[0], dtype=torch.long, device=x_a.device)
        go = alpha < self.threshold
        if go.any():
            fb, hb = self.backbone_b(x_b[go])
            fused = self.fusion(fa[go], fb)
            logits[go] = self.head_fused(torch.cat([fused, ha[go], hb], dim=1))
            level[go] = 3
        return {"logits": logits, "level": level, "alpha": alpha}


def build_model(name: str, num_classes: int, cfg: Optional[dict] = None) -> nn.Module:
    cfg = cfg or {}
    pretrained = cfg.get("pretrained", True)
    name = name.lower()
    if name in ("resnet50", "densenet121", "convnext_tiny", "vit_small_patch16_224", "efficientnet_b0"):
        return SingleStream(num_classes, name, pretrained, stream="a")
    if name == "stream_a":
        return SingleStream(num_classes, cfg.get("backbone", "efficientnet_b0"), pretrained, stream="a")
    if name == "stream_b":
        return SingleStream(num_classes, cfg.get("backbone", "efficientnet_b0"), pretrained, stream="b")
    if name == "always_on":
        return AlwaysOnDual(num_classes, cfg.get("backbone", "efficientnet_b0"), pretrained)
    if name == "second_opinion":
        return SecondOpinion(num_classes, cfg.get("backbone", "efficientnet_b0"), pretrained)
    if name == "arbiter":
        from .arbiter_net import ArbiterConfig, ArbiterNet

        acfg = ArbiterConfig(
            num_classes=num_classes,
            backbone=cfg.get("backbone", "efficientnet_b0"),
            pretrained=pretrained,
            lam=cfg.get("lam", 1.0),
            level_costs=cfg.get("level_costs", [0.0, 0.03, 1.0]),
            ablate=list(cfg.get("ablate", [])),
        )
        return ArbiterNet(acfg)
    raise ValueError(f"unknown model: {name}")
