"""Backbone factory.

Every model in the benchmark draws its encoder from here so that capacity,
pretraining and feature-map resolution are matched across baselines and the
proposed model — otherwise a comparison measures backbone choice, not method.
"""
from __future__ import annotations

from typing import Tuple

import torch
import torch.nn as nn


class BackboneWrapper(nn.Module):
    """Exposes a uniform interface: forward -> (spatial map, pooled vector)."""

    def __init__(self, model: nn.Module, num_features: int):
        super().__init__()
        self.model = model
        self.num_features = num_features

    def forward(self, x: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        feat = self.model.forward_features(x)
        if feat.dim() == 3:  # ViT-style (B, N, C) -> drop cls token, reshape
            if feat.shape[1] in (197, 50, 65):
                feat = feat[:, 1:, :]
            b, n, c = feat.shape
            side = int(round(n ** 0.5))
            feat = feat.transpose(1, 2).reshape(b, c, side, side)
        pooled = feat.mean(dim=(2, 3))
        return feat, pooled


def create_backbone(name: str = "efficientnet_b0", pretrained: bool = True, in_chans: int = 3) -> BackboneWrapper:
    try:
        import timm

        model = timm.create_model(name, pretrained=pretrained, num_classes=0, in_chans=in_chans)
        num_features = model.num_features
        return BackboneWrapper(model, num_features)
    except Exception as exc:  # pragma: no cover - fallback path
        import torchvision.models as tvm

        mapping = {
            "efficientnet_b0": (tvm.efficientnet_b0, 1280),
            "resnet50": (tvm.resnet50, 2048),
            "densenet121": (tvm.densenet121, 1024),
            "convnext_tiny": (tvm.convnext_tiny, 768),
        }
        if name not in mapping:
            raise RuntimeError(f"timm unavailable and no torchvision fallback for {name}") from exc
        ctor, nf = mapping[name]
        net = ctor(weights="DEFAULT" if pretrained else None)

        class _TV(nn.Module):
            def __init__(self, backbone):
                super().__init__()
                if hasattr(backbone, "features"):
                    self.features = backbone.features
                else:  # resnet
                    self.features = nn.Sequential(*list(backbone.children())[:-2])

            def forward_features(self, x):
                return self.features(x)

        return BackboneWrapper(_TV(net), nf)


def freeze_bn(module: nn.Module) -> None:
    for m in module.modules():
        if isinstance(m, nn.BatchNorm2d):
            m.eval()
            for p in m.parameters():
                p.requires_grad = False
