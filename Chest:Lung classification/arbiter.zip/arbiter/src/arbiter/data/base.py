"""Common dataset base shared by every benchmark in this repo.

Each item is a dict:
    x_a   (3,H,W)  raw radiograph replicated to 3 channels, ImageNet-normalised
    x_b   (3,H,W)  anatomy-guided composite [raw, mask, mask-highlighted]
    mask  (1,H,W)  binary anatomy mask in [0,1]
    y     ()       int64 class label
    idx   ()       int64 index into the record list (for XAI / error analysis)
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence

import numpy as np
import torch
from torch.utils.data import Dataset

from .masks import compose_anatomy_input, load_gray, load_mask, otsu_anatomy_mask
from .transforms import AugConfig, normalize_rgb, train_transform


@dataclass
class Record:
    image_path: str
    label: int
    mask_path: Optional[str] = None
    group: str = "default"  # e.g. "visible" / "invisible", body region, patient id


class AnatomyDataset(Dataset):
    def __init__(
        self,
        records: Sequence[Record],
        size: int = 224,
        train: bool = False,
        anatomy_source: str = "otsu",
        anatomy_modality: str = "bone",
        compose_mode: str = "soft",
        aug: Optional[AugConfig] = None,
        mask_root: Optional[str] = None,
        repeat: Optional[Dict[int, int]] = None,
    ):
        self.records: List[Record] = list(records)
        if repeat:  # class-balanced oversampling, e.g. {0: 6, 1: 2}
            expanded: List[Record] = []
            for r in self.records:
                expanded.extend([r] * int(repeat.get(r.label, 1)))
            self.records = expanded
        self.size = size
        self.train = train
        self.anatomy_source = anatomy_source
        self.anatomy_modality = anatomy_modality
        self.compose_mode = compose_mode
        self.aug = aug or AugConfig(size=size)
        self.mask_root = Path(mask_root) if mask_root else None

    def __len__(self) -> int:
        return len(self.records)

    # ------------------------------------------------------------------ #
    def _resolve_mask(self, rec: Record, gray: np.ndarray) -> np.ndarray:
        if self.anatomy_source == "provided" and rec.mask_path and Path(rec.mask_path).exists():
            return load_mask(rec.mask_path, self.size)
        if self.anatomy_source == "unet" and self.mask_root is not None:
            cand = self.mask_root / (Path(rec.image_path).stem + ".png")
            if cand.exists():
                return load_mask(cand, self.size)
        # fallback keeps the pipeline runnable before a segmenter exists
        return otsu_anatomy_mask(gray, modality=self.anatomy_modality, clean=False)

    def __getitem__(self, i: int):
        rec = self.records[i]
        gray = load_gray(rec.image_path, self.size)
        mask = self._resolve_mask(rec, gray)

        img = torch.from_numpy(gray).unsqueeze(0)          # (1,H,W)
        msk = torch.from_numpy(mask).unsqueeze(0)          # (1,H,W)
        if self.train:
            img, msk = train_transform(img, msk, self.aug)

        gray_np = img.squeeze(0).numpy()
        mask_np = msk.squeeze(0).numpy()
        x_b = torch.from_numpy(compose_anatomy_input(gray_np, mask_np, self.compose_mode))
        x_a = img.repeat(3, 1, 1)

        return {
            "x_a": normalize_rgb(x_a),
            "x_b": normalize_rgb(x_b),
            "mask": msk,
            "y": torch.tensor(rec.label, dtype=torch.long),
            "idx": torch.tensor(i, dtype=torch.long),
        }

    # ------------------------------------------------------------------ #
    @property
    def labels(self) -> np.ndarray:
        return np.array([r.label for r in self.records], dtype=np.int64)

    @property
    def groups(self) -> np.ndarray:
        return np.array([r.group for r in self.records])


def class_weights(labels: np.ndarray, num_classes: int) -> torch.Tensor:
    counts = np.bincount(labels, minlength=num_classes).astype(np.float64)
    counts[counts == 0] = 1.0
    w = counts.sum() / (num_classes * counts)
    return torch.tensor(w, dtype=torch.float32)
