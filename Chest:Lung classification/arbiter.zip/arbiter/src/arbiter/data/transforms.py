"""Paired (image, mask) transforms.

Geometric ops must be applied identically to the image and the anatomy mask,
otherwise Stream B is trained on misaligned anatomy. We therefore sample the
parameters once and apply them to both tensors, instead of relying on two
independent transform pipelines.
"""
from __future__ import annotations

import random
from dataclasses import dataclass
from typing import Tuple

import torch
import torch.nn.functional as F


@dataclass
class AugConfig:
    size: int = 224
    hflip: float = 0.5
    rotate_deg: float = 10.0
    translate: float = 0.06
    scale: Tuple[float, float] = (0.92, 1.08)
    shear_deg: float = 5.0
    brightness: float = 0.15
    contrast: float = 0.15
    gamma: Tuple[float, float] = (0.85, 1.15)
    noise_std: float = 0.01


def _affine_grid(theta: torch.Tensor, size) -> torch.Tensor:
    return F.affine_grid(theta, size, align_corners=False)


def _make_theta(angle_deg: float, tx: float, ty: float, scale: float, shear_deg: float) -> torch.Tensor:
    a = torch.tensor(angle_deg * 3.141592653589793 / 180.0)
    sh = torch.tensor(shear_deg * 3.141592653589793 / 180.0)
    cos, sin = torch.cos(a), torch.sin(a)
    rot = torch.tensor([[cos, -sin], [sin, cos]])
    shear = torch.tensor([[1.0, torch.tan(sh).item()], [0.0, 1.0]])
    m = (rot @ shear) / scale
    theta = torch.zeros(1, 2, 3)
    theta[0, :, :2] = m
    theta[0, 0, 2] = tx
    theta[0, 1, 2] = ty
    return theta


def apply_paired_affine(img: torch.Tensor, mask: torch.Tensor, cfg: AugConfig):
    """img: (C,H,W) float, mask: (1,H,W) float -> same shapes, shared geometry."""
    angle = random.uniform(-cfg.rotate_deg, cfg.rotate_deg)
    tx = random.uniform(-cfg.translate, cfg.translate) * 2
    ty = random.uniform(-cfg.translate, cfg.translate) * 2
    scale = random.uniform(*cfg.scale)
    shear = random.uniform(-cfg.shear_deg, cfg.shear_deg)
    theta = _make_theta(angle, tx, ty, scale, shear)

    img4 = img.unsqueeze(0)
    msk4 = mask.unsqueeze(0)
    grid_i = _affine_grid(theta, img4.shape)
    grid_m = _affine_grid(theta, msk4.shape)
    img4 = F.grid_sample(img4, grid_i, mode="bilinear", padding_mode="zeros", align_corners=False)
    msk4 = F.grid_sample(msk4, grid_m, mode="nearest", padding_mode="zeros", align_corners=False)
    return img4.squeeze(0), msk4.squeeze(0)


def photometric(img: torch.Tensor, cfg: AugConfig) -> torch.Tensor:
    """Applied to the image only; the mask carries no intensity information."""
    if cfg.brightness > 0:
        img = img + random.uniform(-cfg.brightness, cfg.brightness)
    if cfg.contrast > 0:
        mean = img.mean()
        factor = 1.0 + random.uniform(-cfg.contrast, cfg.contrast)
        img = (img - mean) * factor + mean
    img = img.clamp(0, 1)
    if cfg.gamma is not None:
        g = random.uniform(*cfg.gamma)
        img = img.clamp(min=1e-6) ** g
    if cfg.noise_std > 0:
        img = img + torch.randn_like(img) * cfg.noise_std
    return img.clamp(0, 1)


def train_transform(img: torch.Tensor, mask: torch.Tensor, cfg: AugConfig):
    if random.random() < cfg.hflip:
        img = torch.flip(img, dims=[-1])
        mask = torch.flip(mask, dims=[-1])
    img, mask = apply_paired_affine(img, mask, cfg)
    img = photometric(img, cfg)
    return img, mask


IMAGENET_MEAN = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
IMAGENET_STD = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)


def normalize_rgb(x3: torch.Tensor) -> torch.Tensor:
    return (x3 - IMAGENET_MEAN.to(x3.device)) / IMAGENET_STD.to(x3.device)


def denormalize_rgb(x3: torch.Tensor) -> torch.Tensor:
    return (x3 * IMAGENET_STD.to(x3.device) + IMAGENET_MEAN.to(x3.device)).clamp(0, 1)
