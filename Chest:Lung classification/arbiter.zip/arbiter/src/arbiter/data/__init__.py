"""Dataset registry and cross-validation splitting."""
from __future__ import annotations

from typing import Any, Dict, List, Sequence, Tuple

import numpy as np

from .base import AnatomyDataset, Record, class_weights
from .cxr import build_covid_records, build_nih_records
from .fracatlas import build_records as build_fracatlas_records
from .transforms import AugConfig

__all__ = [
    "AnatomyDataset",
    "Record",
    "AugConfig",
    "class_weights",
    "build_dataset_records",
    "make_folds",
]


def build_dataset_records(cfg: Dict[str, Any]) -> Tuple[List[Record], List[str]]:
    name = cfg["dataset"]["name"].lower()
    d = cfg["dataset"]
    if name == "fracatlas":
        recs = build_fracatlas_records(d["root"], limit=d.get("limit"))
        classes = ["non_fractured", "fractured"]
    elif name in ("nih", "chestxray14", "nih_cxr14"):
        classes = list(d.get("classes", []))
        recs = build_nih_records(
            d["root"],
            classes=classes or None,  # type: ignore[arg-type]
            max_per_class=d.get("max_per_class", 3000),
        )
        if not classes:
            from .cxr import NIH_DEFAULT_CLASSES

            classes = list(NIH_DEFAULT_CLASSES)
    elif name in ("covid", "covid_radiography"):
        recs = build_covid_records(d["root"], tb_root=d.get("tb_root"))
        from .cxr import COVID_CLASSES

        classes = list(COVID_CLASSES) + (["Tuberculosis"] if d.get("tb_root") else [])
    else:
        raise ValueError(f"unknown dataset: {name}")
    return recs, classes


def make_folds(
    records: Sequence[Record],
    n_splits: int = 5,
    seed: int = 42,
    group_by_patient: bool = False,
) -> List[Tuple[np.ndarray, np.ndarray]]:
    """Stratified k-fold; group-aware when records carry patient ids."""
    y = np.array([r.label for r in records])
    if group_by_patient:
        groups = np.array([r.group for r in records])
        try:
            from sklearn.model_selection import StratifiedGroupKFold

            splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
            return list(splitter.split(np.zeros(len(y)), y, groups))
        except ImportError:  # pragma: no cover
            pass
    from sklearn.model_selection import StratifiedKFold

    splitter = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    return list(splitter.split(np.zeros(len(y)), y))
