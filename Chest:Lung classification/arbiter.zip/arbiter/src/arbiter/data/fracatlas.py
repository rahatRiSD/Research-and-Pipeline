"""FracAtlas (Scientific Data 2023, DOI 10.1038/s41597-023-02432-4).

4,083 musculoskeletal radiographs from 3 Bangladeshi hospitals; 717 images carry
922 annotated fracture instances with per-instance masks and boxes. CC-BY 4.0,
distributed via figshare (10.6084/m9.figshare.22363012) and mirrored on Kaggle.

Expected layout (the loader tolerates minor variations):

    FracAtlas/
      images/Fractured/*.jpg
      images/Non_fractured/*.jpg
      Annotations/COCO/*.json            (fracture instance masks)
      Annotations/PASCAL VOC/*.xml
      dataset.csv                        (per-image metadata: body part, view)

Binary task: 0 = non-fractured, 1 = fractured.
`group` carries the body region (hand / leg / hip / shoulder) so results can be
reported per region, and so a region can be held out to test generalisation.
"""
from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

from .base import Record

BODY_PARTS = ("hand", "leg", "hip", "shoulder")


def _find(root: Path, *names: str) -> Optional[Path]:
    for n in names:
        p = root / n
        if p.exists():
            return p
    for n in names:
        hits = list(root.rglob(n))
        if hits:
            return hits[0]
    return None


def _read_metadata(root: Path) -> Dict[str, str]:
    """image stem -> body region, from dataset.csv when present."""
    meta: Dict[str, str] = {}
    csv_path = _find(root, "dataset.csv", "Dataset.csv")
    if csv_path is None:
        return meta
    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            name = row.get("image_id") or row.get("filename") or row.get("image")
            if not name:
                continue
            stem = Path(name).stem
            region = "unknown"
            for part in BODY_PARTS:
                val = row.get(part) or row.get(part.capitalize())
                if val not in (None, "", "0", 0):
                    region = part
                    break
            meta[stem] = region
    return meta


def build_records(root: str | Path, limit: Optional[int] = None) -> List[Record]:
    root = Path(root)
    frac_dir = _find(root, "images/Fractured", "Fractured")
    norm_dir = _find(root, "images/Non_fractured", "Non_fractured", "images/Non-fractured")
    if frac_dir is None or norm_dir is None:
        raise FileNotFoundError(
            f"Could not locate FracAtlas image folders under {root}. "
            "Expected images/Fractured and images/Non_fractured."
        )
    meta = _read_metadata(root)
    records: List[Record] = []
    for d, label in ((norm_dir, 0), (frac_dir, 1)):
        for p in sorted(list(d.glob("*.jpg")) + list(d.glob("*.png"))):
            records.append(Record(str(p), label, None, meta.get(p.stem, "unknown")))
    if limit:
        rng = np.random.default_rng(0)
        idx = rng.permutation(len(records))[:limit]
        records = [records[i] for i in sorted(idx)]
    return records


# --------------------------------------------------------------------------- #
# COCO fracture masks -> per-image PNG masks (used to train the segmenter)
# --------------------------------------------------------------------------- #
def export_coco_masks(root: str | Path, out_dir: str | Path, size: int = 224) -> int:
    """Rasterise FracAtlas COCO polygons into binary PNG masks.

    These are *lesion* masks covering only the 717 annotated fracture images, so
    they cannot be used directly as the anatomy channel for all 4,083 scans.
    They are the supervision for scripts/train_segmenter.py, whose predictions
    then provide the anatomy channel for every image (train and test alike) —
    the same protocol as anatomy-guided dual-stream baselines.
    """
    from PIL import Image, ImageDraw

    root, out_dir = Path(root), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    coco_dir = _find(root, "Annotations/COCO", "COCO")
    if coco_dir is None:
        raise FileNotFoundError("No Annotations/COCO folder found in FracAtlas root")
    jsons = list(coco_dir.glob("*.json"))
    if not jsons:
        raise FileNotFoundError("No COCO json found")

    written = 0
    for jp in jsons:
        data = json.loads(Path(jp).read_text())
        images = {im["id"]: im for im in data.get("images", [])}
        by_image: Dict[int, list] = {}
        for ann in data.get("annotations", []):
            by_image.setdefault(ann["image_id"], []).append(ann)
        for img_id, anns in by_image.items():
            info = images.get(img_id)
            if info is None:
                continue
            w, h = int(info["width"]), int(info["height"])
            canvas = Image.new("L", (w, h), 0)
            draw = ImageDraw.Draw(canvas)
            for ann in anns:
                seg = ann.get("segmentation")
                if isinstance(seg, list):
                    for poly in seg:
                        if len(poly) >= 6:
                            pts = [(poly[i], poly[i + 1]) for i in range(0, len(poly) - 1, 2)]
                            draw.polygon(pts, fill=255)
                elif "bbox" in ann:
                    x, y, bw, bh = ann["bbox"]
                    draw.rectangle([x, y, x + bw, y + bh], fill=255)
            canvas = canvas.resize((size, size), Image.NEAREST)
            canvas.save(out_dir / (Path(info["file_name"]).stem + ".png"))
            written += 1
    return written
