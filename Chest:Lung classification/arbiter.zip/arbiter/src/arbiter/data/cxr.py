"""Chest radiograph loaders.

Two interchangeable sources, both with published data descriptors:

1. NIH ChestX-ray14 (Wang et al., CVPR 2017) — 112k frontal CXRs, Kaggle
   "NIH Chest X-rays". Natively multi-label; we build a *single-label* subset by
   keeping images whose `Finding Labels` field contains exactly one finding from
   the selected set (plus "No Finding"). This keeps the task compatible with the
   softmax + correctness-router formulation while staying on a large, recent,
   widely benchmarked corpus. Patient-level splitting is enforced via
   `Patient ID`, so no patient appears in both train and test.

2. COVID-19 Radiography Database (Chowdhury et al., IEEE Access 2020; Rahman
   et al., CBM 2021) — ships *ground-truth lung masks* for every image, which
   removes the need for an inferred anatomy channel. Useful as the ablation that
   isolates "does the router behave differently with GT vs predicted anatomy".
"""
from __future__ import annotations

import csv
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Optional, Sequence

from .base import Record

NIH_DEFAULT_CLASSES = (
    "No Finding",
    "Atelectasis",
    "Cardiomegaly",
    "Effusion",
    "Infiltration",
    "Pneumothorax",
)

COVID_CLASSES = ("Normal", "Lung_Opacity", "Viral Pneumonia", "COVID")


# --------------------------------------------------------------------------- #
# NIH ChestX-ray14
# --------------------------------------------------------------------------- #
def _index_images(root: Path) -> Dict[str, Path]:
    index: Dict[str, Path] = {}
    for p in root.rglob("*.png"):
        index.setdefault(p.name, p)
    return index


def build_nih_records(
    root: str | Path,
    classes: Sequence[str] = NIH_DEFAULT_CLASSES,
    max_per_class: Optional[int] = 3000,
    csv_name: str = "Data_Entry_2017.csv",
) -> List[Record]:
    root = Path(root)
    csv_path = None
    for cand in root.rglob("*.csv"):
        if cand.name.lower().startswith("data_entry"):
            csv_path = cand
            break
    if csv_path is None:
        csv_path = root / csv_name
    if not csv_path.exists():
        raise FileNotFoundError(f"ChestX-ray14 metadata csv not found under {root}")

    images = _index_images(root)
    cls_to_idx = {c: i for i, c in enumerate(classes)}
    per_class: Dict[int, int] = defaultdict(int)
    records: List[Record] = []

    with open(csv_path, newline="") as f:
        for row in csv.DictReader(f):
            findings = [t.strip() for t in row["Finding Labels"].split("|") if t.strip()]
            if len(findings) != 1:
                continue
            label_name = findings[0]
            if label_name not in cls_to_idx:
                continue
            y = cls_to_idx[label_name]
            if max_per_class is not None and per_class[y] >= max_per_class:
                continue
            path = images.get(row["Image Index"])
            if path is None:
                continue
            patient = row.get("Patient ID", "unknown")
            records.append(Record(str(path), y, None, f"patient:{patient}"))
            per_class[y] += 1
    if not records:
        raise RuntimeError("No ChestX-ray14 records built — check image folders/csv.")
    return records


def nih_patient_groups(records: Sequence[Record]) -> List[str]:
    """Group key for StratifiedGroupKFold (prevents patient leakage)."""
    return [r.group for r in records]


# --------------------------------------------------------------------------- #
# COVID-19 Radiography Database (ground-truth lung masks included)
# --------------------------------------------------------------------------- #
def build_covid_records(
    root: str | Path,
    classes: Sequence[str] = COVID_CLASSES,
    tb_root: Optional[str | Path] = None,
) -> List[Record]:
    root = Path(root)
    cls_to_idx = {c: i for i, c in enumerate(classes)}
    records: List[Record] = []
    for cname, y in cls_to_idx.items():
        img_dir = root / cname / "images"
        msk_dir = root / cname / "masks"
        if not img_dir.exists():
            img_dir = root / cname
            msk_dir = root / f"{cname}_masks"
        if not img_dir.exists():
            continue
        for p in sorted(img_dir.glob("*.png")):
            m = msk_dir / p.name
            records.append(Record(str(p), y, str(m) if m.exists() else None, cname))
    if tb_root is not None:
        tb_root = Path(tb_root)
        y = len(cls_to_idx)
        for sub in ("Tuberculosis", "TB_Chest_Radiography_Database/Tuberculosis"):
            d = tb_root / sub
            if d.exists():
                for p in sorted(list(d.glob("*.png")) + list(d.glob("*.jpg"))):
                    records.append(Record(str(p), y, None, "Tuberculosis"))
                break
    if not records:
        raise RuntimeError(f"No COVID-19 Radiography records found under {root}")
    return records
