"""Anatomy-mask helpers.

Three anatomy sources are supported, selected via config `anatomy.source`:

  provided   : dataset ships ground-truth masks (e.g. COVID-19 Radiography lung
               masks, FracAtlas COCO fracture masks)
  unet       : masks precomputed by scripts/precompute_masks.py using a U-Net
               trained in scripts/train_segmenter.py (the paper-faithful route)
  otsu       : cheap deterministic fallback so the pipeline is runnable end to
               end before any segmenter is trained (bone / high-density region
               for musculoskeletal X-ray, dark-region complement for CXR)

Every source returns a single-channel float mask in [0, 1] aligned with the
image, which is what the anatomy encoder and Stream B consume.
"""
from __future__ import annotations

from pathlib import Path
from typing import Optional

import numpy as np
from PIL import Image


# --------------------------------------------------------------------------- #
# Loading
# --------------------------------------------------------------------------- #
def load_gray(path: str | Path, size: Optional[int] = None) -> np.ndarray:
    img = Image.open(path).convert("L")
    if size is not None:
        img = img.resize((size, size), Image.BILINEAR)
    return np.asarray(img, dtype=np.float32) / 255.0


def load_mask(path: str | Path, size: Optional[int] = None) -> np.ndarray:
    m = Image.open(path).convert("L")
    if size is not None:
        m = m.resize((size, size), Image.NEAREST)
    m = np.asarray(m, dtype=np.float32)
    if m.max() > 1.0:
        m = m / 255.0
    return (m > 0.5).astype(np.float32)


# --------------------------------------------------------------------------- #
# Otsu fallback
# --------------------------------------------------------------------------- #
def otsu_threshold(gray: np.ndarray, bins: int = 256) -> float:
    hist, edges = np.histogram(gray.ravel(), bins=bins, range=(0.0, 1.0))
    hist = hist.astype(np.float64)
    total = hist.sum()
    if total == 0:
        return 0.5
    p = hist / total
    centers = (edges[:-1] + edges[1:]) / 2.0
    omega = np.cumsum(p)
    mu = np.cumsum(p * centers)
    mu_t = mu[-1]
    denom = omega * (1.0 - omega)
    denom[denom == 0] = 1e-12
    sigma_b = (mu_t * omega - mu) ** 2 / denom
    return float(centers[int(np.argmax(sigma_b))])


def _largest_components(mask: np.ndarray, keep: int = 2) -> np.ndarray:
    """Keep the `keep` largest 4-connected components (pure-numpy flood fill)."""
    h, w = mask.shape
    labels = np.zeros((h, w), dtype=np.int32)
    current = 0
    sizes = {}
    for i in range(h):
        for j in range(w):
            if mask[i, j] <= 0 or labels[i, j] != 0:
                continue
            current += 1
            stack = [(i, j)]
            labels[i, j] = current
            size = 0
            while stack:
                y, x = stack.pop()
                size += 1
                for dy, dx in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                    ny, nx = y + dy, x + dx
                    if 0 <= ny < h and 0 <= nx < w and mask[ny, nx] > 0 and labels[ny, nx] == 0:
                        labels[ny, nx] = current
                        stack.append((ny, nx))
            sizes[current] = size
    if not sizes:
        return mask
    top = sorted(sizes, key=sizes.get, reverse=True)[:keep]
    return np.isin(labels, top).astype(np.float32)


def otsu_anatomy_mask(gray: np.ndarray, modality: str = "bone", clean: bool = False) -> np.ndarray:
    """Deterministic anatomy proxy.

    modality='bone' : bright, dense structures (musculoskeletal radiographs)
    modality='lung' : dark air-filled fields inside the body silhouette (CXR)
    """
    t = otsu_threshold(gray)
    if modality == "bone":
        m = (gray > t).astype(np.float32)
    else:
        body = (gray > max(t * 0.35, 0.05)).astype(np.float32)
        m = ((gray < t) * body).astype(np.float32)
        h, w = m.shape
        border = int(0.06 * h)
        m[:border, :] = 0
        m[-border:, :] = 0
        m[:, :border] = 0
        m[:, -border:] = 0
    if clean:
        m = _largest_components(m, keep=2 if modality == "lung" else 3)
    return m


# --------------------------------------------------------------------------- #
# Anatomy-guided image composition
# --------------------------------------------------------------------------- #
def compose_anatomy_input(gray: np.ndarray, mask: np.ndarray, mode: str = "soft") -> np.ndarray:
    """Build the 3-channel anatomy-guided input consumed by Stream B.

    Channels: [raw image, mask, mask-highlighted image]. This keeps the raw
    signal available (a hard mask destroys peri-lesional context) while making
    the anatomy explicit, and it matches the "segmentation-guided representation"
    used by anatomy-guided dual-stream baselines.
    """
    mask = mask.astype(np.float32)
    if mode == "hard":
        guided = gray * mask
    elif mode == "soft":
        guided = gray * (0.35 + 0.65 * mask)
    elif mode == "outline":
        grad = np.abs(np.gradient(mask)[0]) + np.abs(np.gradient(mask)[1])
        guided = np.clip(gray + (grad > 0).astype(np.float32) * 0.5, 0, 1)
    else:
        raise ValueError(f"unknown compose mode: {mode}")
    return np.stack([gray, mask, guided], axis=0).astype(np.float32)


def save_mask(mask: np.ndarray, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray((mask * 255).astype(np.uint8)).save(path)
