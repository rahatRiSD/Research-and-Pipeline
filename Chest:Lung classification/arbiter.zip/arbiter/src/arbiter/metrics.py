"""Evaluation metrics.

Beyond the usual accuracy/F1/AUROC we report:
  * specificity, macro and per-class, since fracture screening is a sensitivity/
    specificity trade-off rather than an accuracy problem;
  * ECE and Brier for calibration (an adaptive-compute model whose confidence is
    miscalibrated routes badly by construction);
  * routing statistics (level distribution, realised cost, oracle gap);
  * bootstrap CIs and a DeLong test so improvements come with a p-value rather
    than a single decimal point.
"""
from __future__ import annotations

from typing import Dict, Optional, Sequence

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def _specificity(y_true: np.ndarray, y_pred: np.ndarray, num_classes: int) -> float:
    cm = confusion_matrix(y_true, y_pred, labels=list(range(num_classes)))
    specs = []
    total = cm.sum()
    for c in range(num_classes):
        tp = cm[c, c]
        fp = cm[:, c].sum() - tp
        fn = cm[c, :].sum() - tp
        tn = total - tp - fp - fn
        specs.append(tn / max(tn + fp, 1))
    return float(np.mean(specs))


def expected_calibration_error(probs: np.ndarray, y_true: np.ndarray, bins: int = 15) -> float:
    conf = probs.max(axis=1)
    pred = probs.argmax(axis=1)
    acc = (pred == y_true).astype(np.float64)
    edges = np.linspace(0, 1, bins + 1)
    ece = 0.0
    n = len(y_true)
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.sum() == 0:
            continue
        ece += (m.sum() / n) * abs(acc[m].mean() - conf[m].mean())
    return float(ece)


def brier_score(probs: np.ndarray, y_true: np.ndarray, num_classes: int) -> float:
    onehot = np.eye(num_classes)[y_true]
    return float(((probs - onehot) ** 2).sum(axis=1).mean())


def compute_metrics(y_true: np.ndarray, probs: np.ndarray, num_classes: int) -> Dict[str, float]:
    y_pred = probs.argmax(axis=1)
    avg = "binary" if num_classes == 2 else "macro"
    out = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision": float(precision_score(y_true, y_pred, average=avg, zero_division=0)),
        "recall": float(recall_score(y_true, y_pred, average=avg, zero_division=0)),
        "specificity": _specificity(y_true, y_pred, num_classes),
        "f1": float(f1_score(y_true, y_pred, average=avg, zero_division=0)),
        "ece": expected_calibration_error(probs, y_true),
        "brier": brier_score(probs, y_true, num_classes),
    }
    try:
        if num_classes == 2:
            out["auroc"] = float(roc_auc_score(y_true, probs[:, 1]))
        else:
            out["auroc"] = float(roc_auc_score(y_true, probs, multi_class="ovr", average="macro"))
    except ValueError:
        out["auroc"] = float("nan")
    # PelFANet-style F1 (harmonic mean of recall and specificity), for
    # comparability with the fracture-detection literature
    r, s = out["recall"], out["specificity"]
    out["f1_rs"] = float(2 * r * s / (r + s)) if (r + s) > 0 else 0.0
    return out


# --------------------------------------------------------------------------- #
# Routing metrics
# --------------------------------------------------------------------------- #
def routing_metrics(levels: np.ndarray, y_true: np.ndarray, probs: np.ndarray,
                    level_logits: Optional[Dict[int, np.ndarray]] = None,
                    costs: Sequence[float] = (0.400, 0.412, 0.855)) -> Dict[str, float]:
    out: Dict[str, float] = {}
    n = len(levels)
    for k in (1, 2, 3):
        out[f"frac_level{k}"] = float((levels == k).mean())
    out["mean_gflops"] = float(np.mean([costs[int(l) - 1] for l in levels]))
    out["escalation_rate"] = float((levels > 1).mean())
    out["deep_rate"] = float((levels == 3).mean())

    correct = (probs.argmax(1) == y_true)
    for k in (1, 2, 3):
        m = levels == k
        out[f"acc_at_level{k}"] = float(correct[m].mean()) if m.sum() else float("nan")

    if level_logits is not None:
        # Oracle: the cheapest level that would have been correct.
        per_level_correct = np.stack([level_logits[k].argmax(1) == y_true for k in (1, 2, 3)], axis=1)
        oracle_level = np.where(per_level_correct.any(axis=1),
                                per_level_correct.argmax(axis=1) + 1, 3)
        out["oracle_accuracy"] = float(per_level_correct.any(axis=1).mean())
        out["oracle_mean_gflops"] = float(np.mean([costs[int(l) - 1] for l in oracle_level]))
        out["routing_regret"] = float(out["oracle_accuracy"] - correct.mean())
        out["router_agreement"] = float((levels == oracle_level).mean())
    out["n"] = float(n)
    return out


# --------------------------------------------------------------------------- #
# Uncertainty quantification
# --------------------------------------------------------------------------- #
def bootstrap_ci(y_true: np.ndarray, probs: np.ndarray, num_classes: int,
                 metric: str = "accuracy", n_boot: int = 1000, seed: int = 0,
                 alpha: float = 0.05) -> Dict[str, float]:
    rng = np.random.default_rng(seed)
    n = len(y_true)
    vals = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if len(np.unique(y_true[idx])) < 2:
            continue
        vals.append(compute_metrics(y_true[idx], probs[idx], num_classes)[metric])
    if not vals:
        return {"mean": float("nan"), "lo": float("nan"), "hi": float("nan")}
    vals = np.array(vals)
    return {"mean": float(vals.mean()),
            "lo": float(np.quantile(vals, alpha / 2)),
            "hi": float(np.quantile(vals, 1 - alpha / 2))}


def delong_test(y_true: np.ndarray, score_a: np.ndarray, score_b: np.ndarray) -> float:
    """Two-sided p-value for the difference of two correlated AUCs."""
    from scipy import stats

    order = np.argsort(-np.concatenate([score_a, score_b]))
    del order  # kept for clarity; computation below is the fast midrank version

    def _midrank(x):
        j = np.argsort(x)
        z = x[j]
        n = len(x)
        t = np.zeros(n)
        i = 0
        while i < n:
            k = i
            while k < n and z[k] == z[i]:
                k += 1
            t[i:k] = 0.5 * (i + k - 1) + 1
            i = k
        out = np.empty(n)
        out[j] = t
        return out

    pos = y_true == 1
    neg = ~pos
    m, n = pos.sum(), neg.sum()
    if m == 0 or n == 0:
        return float("nan")
    preds = np.vstack([score_a, score_b])
    tx = np.array([_midrank(p[pos]) for p in preds])
    ty = np.array([_midrank(p[neg]) for p in preds])
    tz = np.array([_midrank(p) for p in preds])
    aucs = (tz[:, :m].sum(axis=1) - m * (m + 1) / 2) / (m * n)
    v01 = (tz[:, :m] - tx) / n
    v10 = 1 - (tz[:, m:] - ty) / m
    s01 = np.cov(v01)
    s10 = np.cov(v10)
    s = s01 / m + s10 / n
    diff = aucs[0] - aucs[1]
    var = s[0, 0] + s[1, 1] - 2 * s[0, 1]
    if var <= 0:
        return float("nan")
    z = diff / np.sqrt(var)
    return float(2 * (1 - stats.norm.cdf(abs(z))))


def aggregate_folds(fold_metrics: Sequence[Dict[str, float]]) -> Dict[str, Dict[str, float]]:
    """Mean and 95% CI (z-approximation over folds), matching the paper's tables."""
    keys = set().union(*[set(m.keys()) for m in fold_metrics])
    out: Dict[str, Dict[str, float]] = {}
    for k in sorted(keys):
        vals = np.array([m[k] for m in fold_metrics if k in m and not np.isnan(m[k])], dtype=float)
        if len(vals) == 0:
            continue
        mean = vals.mean()
        half = 1.96 * vals.std(ddof=1) / np.sqrt(len(vals)) if len(vals) > 1 else 0.0
        out[k] = {"mean": float(mean), "ci95": float(half), "std": float(vals.std(ddof=1)) if len(vals) > 1 else 0.0}
    return out
