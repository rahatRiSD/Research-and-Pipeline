"""Shared utilities: seeding, config handling, logging, cost accounting."""
from __future__ import annotations

import json
import logging
import os
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict

import numpy as np
import torch


# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
def set_seed(seed: int = 42, deterministic: bool = True) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.benchmark = True


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


# --------------------------------------------------------------------------- #
# Config
# --------------------------------------------------------------------------- #
def load_config(path: str | Path) -> Dict[str, Any]:
    """Load a YAML config. Falls back to json if pyyaml is unavailable."""
    path = Path(path)
    text = path.read_text()
    try:
        import yaml  # type: ignore

        return yaml.safe_load(text)
    except ImportError:  # pragma: no cover
        return json.loads(text)


def save_json(obj: Any, path: str | Path) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2, default=_json_default)


def _json_default(o: Any):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, Path):
        return str(o)
    return str(o)


def load_json(path: str | Path) -> Any:
    with open(path) as f:
        return json.load(f)


# --------------------------------------------------------------------------- #
# Logging
# --------------------------------------------------------------------------- #
def get_logger(name: str = "arbiter", logfile: str | Path | None = None) -> logging.Logger:
    logger = logging.getLogger(name)
    if logger.handlers:
        return logger
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter("[%(asctime)s] %(levelname)s | %(message)s", "%H:%M:%S")
    sh = logging.StreamHandler()
    sh.setFormatter(fmt)
    logger.addHandler(sh)
    if logfile is not None:
        Path(logfile).parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(logfile)
        fh.setFormatter(fmt)
        logger.addHandler(fh)
    return logger


# --------------------------------------------------------------------------- #
# Cost accounting (params / FLOPs)
# --------------------------------------------------------------------------- #
@dataclass
class CostReport:
    params_m: float = 0.0
    gflops: float = 0.0
    per_module: Dict[str, Dict[str, float]] = field(default_factory=dict)


def count_params(module: torch.nn.Module) -> float:
    """Trainable parameters in millions."""
    return sum(p.numel() for p in module.parameters() if p.requires_grad) / 1e6


def count_flops(module: torch.nn.Module, input_shapes, device="cpu") -> float:
    """GFLOPs (multiply-adds counted as 2 ops when using thop/fvcore conventions).

    Uses ptflops -> thop -> fvcore in order of availability; returns 0.0 if none
    installed so that training never crashes because of a profiling dependency.
    """
    module = module.to(device).eval()
    inputs = tuple(torch.randn(1, *s, device=device) for s in input_shapes)
    try:
        from fvcore.nn import FlopCountAnalysis  # type: ignore

        with torch.no_grad():
            flops = FlopCountAnalysis(module, inputs)
            flops.unsupported_ops_warnings(False)
            flops.uncalled_modules_warnings(False)
            return float(flops.total()) / 1e9
    except Exception:
        pass
    try:
        from thop import profile  # type: ignore

        with torch.no_grad():
            macs, _ = profile(module, inputs=inputs, verbose=False)
        return float(macs) / 1e9
    except Exception:
        return 0.0


def maybe_makedirs(*paths: str | Path) -> None:
    for p in paths:
        Path(p).mkdir(parents=True, exist_ok=True)


def env_flag(name: str, default: bool = False) -> bool:
    val = os.environ.get(name)
    if val is None:
        return default
    return val.lower() in {"1", "true", "yes", "on"}
