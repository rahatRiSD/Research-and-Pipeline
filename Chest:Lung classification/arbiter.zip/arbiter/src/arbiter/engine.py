"""Training and evaluation engine.

One code path serves every model in the benchmark: baselines expose
`forward(x_a, x_b, mask) -> {"logits": ...}`, gated models additionally expose
`infer(...) -> {"logits", "level"}`. Evaluation always uses `infer` when it
exists, so reported compute is the compute actually spent under hard routing,
not a soft-gated approximation.
"""
from __future__ import annotations

import copy
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader

from .losses import build_loss
from .metrics import aggregate_folds, compute_metrics, routing_metrics
from .utils import get_logger, save_json, set_seed

LOG = get_logger()


# --------------------------------------------------------------------------- #
class EMA:
    def __init__(self, model: nn.Module, decay: float = 0.999):
        self.decay = decay
        self.shadow = {k: v.detach().clone() for k, v in model.state_dict().items()}

    @torch.no_grad()
    def update(self, model: nn.Module) -> None:
        for k, v in model.state_dict().items():
            if v.dtype.is_floating_point:
                self.shadow[k].mul_(self.decay).add_(v.detach(), alpha=1 - self.decay)
            else:
                self.shadow[k] = v.detach().clone()

    def copy_to(self, model: nn.Module) -> None:
        model.load_state_dict(self.shadow, strict=False)


# --------------------------------------------------------------------------- #
def _forward(model: nn.Module, batch: Dict[str, torch.Tensor], device) -> Dict[str, torch.Tensor]:
    return model(batch["x_a"].to(device, non_blocking=True),
                 batch["x_b"].to(device, non_blocking=True),
                 batch["mask"].to(device, non_blocking=True))


def train_one_epoch(model, loader, criterion, optimizer, device, epoch: int,
                    scaler=None, ema: Optional[EMA] = None, grad_clip: float = 5.0,
                    log_every: int = 50) -> Dict[str, float]:
    model.train()
    agg: Dict[str, float] = {}
    n = 0
    t0 = time.time()
    for i, batch in enumerate(loader):
        y = batch["y"].to(device, non_blocking=True)
        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, enabled=scaler is not None):
            out = _forward(model, batch, device)
            losses = criterion(out, y, epoch)
        loss = losses["loss"]
        if scaler is not None:
            scaler.scale(loss).backward()
            scaler.unscale_(optimizer)
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            optimizer.step()
        if ema is not None:
            ema.update(model)

        bs = y.size(0)
        n += bs
        for k, v in losses.items():
            agg[k] = agg.get(k, 0.0) + float(v.detach()) * bs
        if log_every and i % log_every == 0:
            LOG.info(f"  ep{epoch} step {i}/{len(loader)} loss={float(loss.detach()):.4f}")
    agg = {k: v / max(n, 1) for k, v in agg.items()}
    agg["epoch_time_s"] = time.time() - t0
    return agg


@torch.no_grad()
def evaluate(model, loader, device, num_classes: int, lam: Optional[float] = None,
             collect_levels: bool = True, costs: Sequence[float] = (0.4, 0.412, 0.855)) -> Dict[str, Any]:
    model.eval()
    probs_all, y_all, level_all, idx_all = [], [], [], []
    per_level = {1: [], 2: [], 3: []}
    has_infer = hasattr(model, "infer")

    for batch in loader:
        x_a = batch["x_a"].to(device)
        x_b = batch["x_b"].to(device)
        mask = batch["mask"].to(device)
        if has_infer:
            kwargs = {"lam": lam} if lam is not None and hasattr(model, "set_budget") else {}
            out = model.infer(x_a, x_b, mask, **kwargs)
            levels = out.get("level", torch.ones(x_a.shape[0], dtype=torch.long, device=device))
        else:
            out = model(x_a, x_b, mask)
            levels = torch.full((x_a.shape[0],), 3 if "fused" in out else 1, dtype=torch.long, device=device)
        probs_all.append(out["logits"].softmax(1).float().cpu().numpy())
        level_all.append(levels.cpu().numpy())
        y_all.append(batch["y"].numpy())
        idx_all.append(batch["idx"].numpy())

        if collect_levels and hasattr(model, "forward_level2"):
            state = model.forward_level1(x_a)
            state = model.forward_level2(state, mask)
            state = model.forward_level3(state, x_b)
            for k, key in ((1, "z1"), (2, "z2"), (3, "z3")):
                per_level[k].append(state[key].float().cpu().numpy())

    probs = np.concatenate(probs_all)
    y = np.concatenate(y_all)
    levels = np.concatenate(level_all)
    idx = np.concatenate(idx_all)

    res: Dict[str, Any] = compute_metrics(y, probs, num_classes)
    level_logits = {k: np.concatenate(v) for k, v in per_level.items() if v} or None
    res.update(routing_metrics(levels, y, probs, level_logits, costs))
    res["_probs"] = probs
    res["_y"] = y
    res["_levels"] = levels
    res["_idx"] = idx
    if level_logits is not None:
        res["_level_logits"] = level_logits
    return res


# --------------------------------------------------------------------------- #
def budget_sweep(model, loader, device, num_classes: int,
                 lams: Sequence[float] = (0.0, 0.05, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0, 1.5, 3.0),
                 costs: Sequence[float] = (0.4, 0.412, 0.855)) -> List[Dict[str, float]]:
    """Trace the accuracy/compute Pareto front from a single trained model."""
    curve = []
    if not hasattr(model, "set_budget"):
        return curve
    original = model.cfg.lam
    for lam in lams:
        model.set_budget(lam)
        r = evaluate(model, loader, device, num_classes, lam=lam, collect_levels=False, costs=costs)
        curve.append({"lam": float(lam),
                      **{k: v for k, v in r.items() if not k.startswith("_")}})
    model.set_budget(original)
    return curve


# --------------------------------------------------------------------------- #
def fit(model, train_loader, val_loader, cfg: Dict[str, Any], device, model_name: str,
        num_classes: int, class_weight: Optional[torch.Tensor] = None,
        out_dir: Optional[Path] = None) -> Dict[str, Any]:
    tcfg = cfg["train"]
    criterion = build_loss(model_name, num_classes, class_weight, cfg.get("loss", {})).to(device)
    params = [p for p in model.parameters() if p.requires_grad]
    optimizer = torch.optim.AdamW(params, lr=tcfg["lr"], weight_decay=tcfg.get("weight_decay", 1e-4))
    epochs = int(tcfg["epochs"])
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=epochs,
                                                           eta_min=tcfg.get("min_lr", 1e-6))
    scaler = torch.amp.GradScaler(device.type) if (tcfg.get("amp", True) and device.type == "cuda") else None
    ema = EMA(model, tcfg.get("ema_decay", 0.999)) if tcfg.get("ema", True) else None

    best_score, best_state, best_epoch = -np.inf, None, -1
    monitor = tcfg.get("monitor", "auroc")
    history = []
    patience = tcfg.get("early_stop_patience", 0)
    bad = 0

    for epoch in range(epochs):
        tr = train_one_epoch(model, train_loader, criterion, optimizer, device, epoch, scaler, ema,
                             grad_clip=tcfg.get("grad_clip", 5.0), log_every=tcfg.get("log_every", 50))
        scheduler.step()
        va = evaluate(model, val_loader, device, num_classes, collect_levels=False)
        score = va.get(monitor, va["accuracy"])
        history.append({"epoch": epoch, **{k: v for k, v in tr.items()},
                        **{f"val_{k}": v for k, v in va.items() if not k.startswith("_")}})
        LOG.info(f"[{model_name}] ep {epoch+1}/{epochs} "
                 f"loss={tr['loss']:.4f} val_acc={va['accuracy']:.4f} val_{monitor}={score:.4f}")
        if score > best_score:
            best_score, best_epoch = score, epoch
            best_state = copy.deepcopy(model.state_dict())
            bad = 0
        else:
            bad += 1
            if patience and bad >= patience:
                LOG.info(f"[{model_name}] early stop at epoch {epoch+1}")
                break

    if ema is not None and tcfg.get("use_ema_weights", False):
        ema.copy_to(model)
    elif best_state is not None:
        model.load_state_dict(best_state)

    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        torch.save(model.state_dict(), out_dir / "weights.pt")
        save_json(history, out_dir / "history.json")
    return {"best_epoch": best_epoch, "best_score": best_score, "history": history}


def make_loaders(train_ds, val_ds, cfg: Dict[str, Any]):
    tc = cfg["train"]
    train_loader = DataLoader(train_ds, batch_size=tc["batch_size"], shuffle=True,
                              num_workers=tc.get("num_workers", 2), pin_memory=True,
                              drop_last=len(train_ds) > tc["batch_size"], persistent_workers=tc.get("num_workers", 2) > 0)
    val_loader = DataLoader(val_ds, batch_size=tc.get("eval_batch_size", tc["batch_size"]), shuffle=False,
                            num_workers=tc.get("num_workers", 2), pin_memory=True)
    return train_loader, val_loader


__all__ = ["fit", "evaluate", "train_one_epoch", "budget_sweep", "make_loaders",
           "aggregate_folds", "set_seed", "EMA"]
