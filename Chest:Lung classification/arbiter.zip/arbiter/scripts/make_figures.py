#!/usr/bin/env python3
"""Build the quantitative paper figures (1, 2, 3, 5, 6). Figure 4, the
qualitative XAI panel, is produced by scripts/make_xai.py.

  Fig 1  Architecture schematic (vector, drawn from the actual level costs)
  Fig 2  Routing behaviour: level mix per dataset + escalation vs difficulty
  Fig 3  Accuracy-compute Pareto front from the budget sweep, with baselines
  Fig 5  Reliability diagrams (ARBITER vs the strongest baseline)
  Fig 6  Confusion matrices and per-level accuracy breakdown
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

plt.rcParams.update({
    "figure.dpi": 160, "savefig.dpi": 300, "font.size": 9,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.alpha": 0.25, "grid.linestyle": ":",
    "savefig.bbox": "tight",
})

PALETTE = {"l1": "#4C72B0", "l2": "#DD8452", "l3": "#C44E52",
           "ours": "#C44E52", "base": "#8C8C8C", "prior": "#55A868"}


def load_runs(runs_dir: Path):
    out = {}
    for s in runs_dir.rglob("summary.json"):
        out.setdefault(s.parent.parent.name, {})[s.parent.name] = json.loads(s.read_text())
    return out


def mean(summary, key, default=np.nan):
    return summary.get("summary", {}).get(key, {}).get("mean", default)


# --------------------------------------------------------------------------- #
def fig1_architecture(out: Path):
    fig, ax = plt.subplots(figsize=(11, 4.6))
    ax.axis("off")

    def box(x, y, w, h, text, color, fs=8.5, alpha=0.18):
        ax.add_patch(plt.Rectangle((x, y), w, h, facecolor=color, alpha=alpha,
                                   edgecolor=color, linewidth=1.4, zorder=2))
        ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, zorder=3)

    def arrow(x1, y1, x2, y2, text="", style="-|>", color="#444", ls="-"):
        ax.annotate("", xy=(x2, y2), xytext=(x1, y1),
                    arrowprops=dict(arrowstyle=style, color=color, lw=1.2, linestyle=ls))
        if text:
            ax.text((x1 + x2) / 2, (y1 + y2) / 2 + 0.035, text, ha="center", fontsize=7.5, color=color)

    box(0.01, 0.42, 0.10, 0.16, "Radiograph\n$x$", "#333")
    box(0.01, 0.06, 0.10, 0.16, "U-Net\nanatomy mask $m$", "#666")

    box(0.16, 0.42, 0.15, 0.16, "Backbone A\n(EfficientNet-B0)", PALETTE["l1"])
    box(0.35, 0.60, 0.13, 0.13, "Head $z_1$\nLEVEL 1", PALETTE["l1"])

    box(0.16, 0.06, 0.15, 0.16, "Anatomy encoder\n(0.4M params)", PALETTE["l2"])
    box(0.35, 0.30, 0.15, 0.16, "FiLM + spatial gate\nLEVEL 2  ($z_2$)", PALETTE["l2"])

    box(0.55, 0.06, 0.15, 0.16, "Backbone B\n(anatomy-guided)", PALETTE["l3"])
    box(0.74, 0.22, 0.16, 0.18, "Cross-attention\nfusion  LEVEL 3 ($z_3$)", PALETTE["l3"])

    box(0.55, 0.58, 0.18, 0.20,
        "Utility router\n$r_k=P(\\mathrm{level}\\ k\\ \\mathrm{correct})$\n"
        "escalate iff $r_{k+1}-r_k>\\lambda\\Delta c$", "#9467bd", fs=8)
    box(0.78, 0.60, 0.13, 0.16, "Evidential head\n$u=C/S$", "#8c564b", fs=8)

    arrow(0.11, 0.50, 0.16, 0.50)
    arrow(0.11, 0.14, 0.16, 0.14)
    arrow(0.31, 0.50, 0.35, 0.63)
    arrow(0.31, 0.14, 0.38, 0.30)
    arrow(0.24, 0.42, 0.40, 0.30, text="", style="->")
    arrow(0.44, 0.60, 0.58, 0.58, text="evidence")
    arrow(0.50, 0.38, 0.74, 0.31)
    arrow(0.70, 0.14, 0.78, 0.22)
    arrow(0.73, 0.66, 0.78, 0.66)
    arrow(0.64, 0.58, 0.55, 0.46, text="gate $g_2$", style="-|>", ls="--")
    arrow(0.70, 0.58, 0.82, 0.41, text="gate $g_3$", style="-|>", ls="--")

    ax.text(0.5, 0.95, "ARBITER: three-rung anatomy-routed cascade with a budget knob $\\lambda$",
            ha="center", fontsize=10.5)
    ax.text(0.5, 0.885, "+0.00 GFLOPs (L1)   |   +0.012 GFLOPs (L2)   |   +0.455 GFLOPs (L3)",
            ha="center", fontsize=8, color="#555")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    fig.savefig(out / "fig1_architecture.png")
    fig.savefig(out / "fig1_architecture.pdf")
    plt.close(fig)


# --------------------------------------------------------------------------- #
def fig2_routing(runs, out: Path):
    datasets = sorted(runs.keys())
    fig, axes = plt.subplots(1, 2, figsize=(9.5, 3.4))

    labels, l1, l2, l3 = [], [], [], []
    for ds in datasets:
        s = runs[ds].get("arbiter")
        if not s:
            continue
        labels.append(ds)
        l1.append(mean(s, "frac_level1", 0) * 100)
        l2.append(mean(s, "frac_level2", 0) * 100)
        l3.append(mean(s, "frac_level3", 0) * 100)
    x = np.arange(len(labels))
    axes[0].bar(x, l1, color=PALETTE["l1"], label="L1 raw only")
    axes[0].bar(x, l2, bottom=l1, color=PALETTE["l2"], label="L2 FiLM anatomy")
    axes[0].bar(x, l3, bottom=np.array(l1) + np.array(l2), color=PALETTE["l3"], label="L3 dual + fusion")
    axes[0].set_xticks(x)
    axes[0].set_xticklabels(labels, fontsize=8)
    axes[0].set_ylabel("% of test cases")
    axes[0].set_title("Where cases are resolved")
    axes[0].legend(fontsize=7, frameon=False)

    # escalation vs task difficulty, proxied by the single-stream error rate
    xs, ys, names = [], [], []
    for ds in datasets:
        a, sa = runs[ds].get("arbiter"), runs[ds].get("stream_a")
        if not a or not sa:
            continue
        xs.append((1 - mean(sa, "accuracy", np.nan)) * 100)
        ys.append(mean(a, "escalation_rate", np.nan) * 100)
        names.append(ds)
    if xs:
        axes[1].scatter(xs, ys, s=60, color=PALETTE["ours"], zorder=3)
        for xi, yi, n in zip(xs, ys, names):
            axes[1].annotate(n, (xi, yi), textcoords="offset points", xytext=(6, 4), fontsize=7.5)
        if len(xs) > 1:
            k = np.polyfit(xs, ys, 1)
            gx = np.linspace(min(xs) * 0.8, max(xs) * 1.2, 20)
            axes[1].plot(gx, np.polyval(k, gx), ls="--", color="#999", lw=1)
    axes[1].set_xlabel("Task difficulty: single-stream error rate (%)")
    axes[1].set_ylabel("Escalation rate (%)")
    axes[1].set_title("Compute tracks difficulty")

    fig.tight_layout()
    fig.savefig(out / "fig2_routing.png")
    fig.savefig(out / "fig2_routing.pdf")
    plt.close(fig)


# --------------------------------------------------------------------------- #
def fig3_pareto(runs_dir: Path, runs, out: Path):
    datasets = sorted(runs.keys())
    n = max(len(datasets), 1)
    fig, axes = plt.subplots(1, n, figsize=(4.6 * n, 3.5), squeeze=False)
    for ax, ds in zip(axes[0], datasets):
        sweep_path = runs_dir / ds / "arbiter" / "budget_sweep.json"
        if sweep_path.exists():
            sweeps = json.loads(sweep_path.read_text())
            # average the folds at each lambda
            by_lam = {}
            for fold in sweeps:
                for pt in fold:
                    by_lam.setdefault(pt["lam"], []).append(pt)
            lams = sorted(by_lam)
            gf = [np.mean([p["mean_gflops"] for p in by_lam[l]]) for l in lams]
            acc = [np.mean([p["accuracy"] for p in by_lam[l]]) * 100 for l in lams]
            err = [np.std([p["accuracy"] for p in by_lam[l]]) * 100 for l in lams]
            ax.errorbar(gf, acc, yerr=err, marker="o", ms=4, lw=1.6, capsize=2,
                        color=PALETTE["ours"], label="ARBITER ($\\lambda$ sweep)")
            for l, x, y in zip(lams, gf, acc):
                if l in (0.0, 0.2, 1.0, 3.0):
                    ax.annotate(f"$\\lambda$={l:g}", (x, y), fontsize=6.5,
                                textcoords="offset points", xytext=(4, -9))
        for m, color, marker in (("stream_a", PALETTE["base"], "s"),
                                 ("always_on", "#444", "^"),
                                 ("second_opinion", PALETTE["prior"], "D")):
            s = runs[ds].get(m)
            if not s:
                continue
            g = mean(s, "mean_gflops", np.nan)
            a = mean(s, "accuracy", np.nan) * 100
            ax.scatter([g], [a], color=color, marker=marker, s=48, zorder=4,
                       label=m.replace("_", " "))
        ax.set_xlabel("Inference cost (GFLOPs / case)")
        ax.set_ylabel("Accuracy (%)")
        ax.set_title(ds)
        ax.legend(fontsize=7, frameon=False, loc="lower right")
    fig.tight_layout()
    fig.savefig(out / "fig3_pareto.png")
    fig.savefig(out / "fig3_pareto.pdf")
    plt.close(fig)


# --------------------------------------------------------------------------- #
def _reliability(ax, probs, y, label, color, bins=12):
    conf = probs.max(1)
    pred = probs.argmax(1)
    acc = (pred == y).astype(float)
    edges = np.linspace(0, 1, bins + 1)
    xs, ys = [], []
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.sum() < 5:
            continue
        xs.append(conf[m].mean())
        ys.append(acc[m].mean())
    ece = 0.0
    for lo, hi in zip(edges[:-1], edges[1:]):
        m = (conf > lo) & (conf <= hi)
        if m.sum():
            ece += m.mean() * abs(acc[m].mean() - conf[m].mean())
    ax.plot(xs, ys, marker="o", ms=4, color=color, label=f"{label} (ECE={ece:.3f})")


def _collect_preds(runs_dir: Path, ds: str, model: str):
    ps, ys, lv = [], [], []
    for f in sorted((runs_dir / ds / model).glob("fold*/preds.npz")):
        d = np.load(f)
        ps.append(d["probs"])
        ys.append(d["y"])
        lv.append(d["levels"])
    if not ps:
        return None
    return np.concatenate(ps), np.concatenate(ys), np.concatenate(lv)


def fig5_reliability(runs_dir: Path, runs, out: Path):
    datasets = sorted(runs.keys())
    fig, axes = plt.subplots(1, max(len(datasets), 1), figsize=(4.3 * max(len(datasets), 1), 3.5),
                             squeeze=False)
    for ax, ds in zip(axes[0], datasets):
        ax.plot([0, 1], [0, 1], ls="--", lw=1, color="#999")
        for m, color in (("stream_a", PALETTE["base"]),
                         ("second_opinion", PALETTE["prior"]),
                         ("arbiter", PALETTE["ours"])):
            got = _collect_preds(runs_dir, ds, m)
            if got:
                _reliability(ax, got[0], got[1], m.replace("_", " "), color)
        ax.set_xlabel("Confidence")
        ax.set_ylabel("Empirical accuracy")
        ax.set_title(f"Calibration — {ds}")
        ax.legend(fontsize=7, frameon=False, loc="upper left")
    fig.tight_layout()
    fig.savefig(out / "fig5_reliability.png")
    fig.savefig(out / "fig5_reliability.pdf")
    plt.close(fig)


# --------------------------------------------------------------------------- #
def fig6_confusion_and_levels(runs_dir: Path, runs, out: Path):
    from sklearn.metrics import confusion_matrix

    datasets = sorted(runs.keys())
    fig, axes = plt.subplots(2, max(len(datasets), 1), figsize=(4.3 * max(len(datasets), 1), 6.6),
                             squeeze=False)
    for j, ds in enumerate(datasets):
        got = _collect_preds(runs_dir, ds, "arbiter")
        if not got:
            continue
        probs, y, levels = got
        cm = confusion_matrix(y, probs.argmax(1))
        cmn = cm / np.maximum(cm.sum(1, keepdims=True), 1)
        ax = axes[0][j]
        im = ax.imshow(cmn, cmap="Blues", vmin=0, vmax=1)
        for a in range(cm.shape[0]):
            for b in range(cm.shape[1]):
                ax.text(b, a, f"{cmn[a,b]:.2f}", ha="center", va="center", fontsize=7,
                        color="white" if cmn[a, b] > 0.5 else "black")
        ax.set_title(f"ARBITER confusion — {ds}")
        ax.set_xlabel("Predicted")
        ax.set_ylabel("True")
        ax.grid(False)
        fig.colorbar(im, ax=ax, fraction=0.045)

        ax = axes[1][j]
        ks, accs, shares = [], [], []
        for k in (1, 2, 3):
            m = levels == k
            if m.sum() == 0:
                continue
            ks.append(f"L{k}\n(n={int(m.sum())})")
            accs.append((probs[m].argmax(1) == y[m]).mean() * 100)
            shares.append(m.mean() * 100)
        bars = ax.bar(ks, accs, color=[PALETTE["l1"], PALETTE["l2"], PALETTE["l3"]][:len(ks)])
        for b, s in zip(bars, shares):
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 1, f"{s:.1f}% of cases",
                    ha="center", fontsize=7)
        ax.set_ylim(0, 105)
        ax.set_ylabel("Accuracy within level (%)")
        ax.set_title("Accuracy by routed level")
    fig.tight_layout()
    fig.savefig(out / "fig6_confusion_levels.png")
    fig.savefig(out / "fig6_confusion_levels.pdf")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="paper/figures")
    args = ap.parse_args()
    runs_dir, out = Path(args.runs), Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    runs = load_runs(runs_dir)

    fig1_architecture(out)
    if runs:
        fig2_routing(runs, out)
        fig3_pareto(runs_dir, runs, out)
        fig5_reliability(runs_dir, runs, out)
        fig6_confusion_and_levels(runs_dir, runs, out)
    print(f"figures written to {out}")


if __name__ == "__main__":
    main()
