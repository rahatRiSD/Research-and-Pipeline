#!/usr/bin/env python3
"""Train + evaluate one model with k-fold cross-validation.

Example
-------
python scripts/train.py --config configs/fracatlas.yaml --model arbiter
python scripts/train.py --config configs/nih_cxr14.yaml --model second_opinion --folds 5
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from arbiter.data import AnatomyDataset, AugConfig, build_dataset_records, class_weights, make_folds  # noqa: E402
from arbiter.engine import budget_sweep, evaluate, fit, make_loaders  # noqa: E402
from arbiter.metrics import aggregate_folds, bootstrap_ci  # noqa: E402
from arbiter.models import build_model  # noqa: E402
from arbiter.utils import (count_flops, count_params, get_device, get_logger,  # noqa: E402
                           load_config, save_json, set_seed)


def build_datasets(cfg, records, train_idx, val_idx):
    d = cfg["dataset"]
    a = cfg.get("anatomy", {})
    aug = AugConfig(size=d.get("size", 224), **cfg.get("aug", {}))
    common = dict(
        size=d.get("size", 224),
        anatomy_source=a.get("source", "otsu"),
        anatomy_modality=a.get("modality", "bone"),
        compose_mode=a.get("compose", "soft"),
        mask_root=a.get("mask_root"),
    )
    train_ds = AnatomyDataset([records[i] for i in train_idx], train=True, aug=aug,
                              repeat=d.get("oversample"), **common)
    val_ds = AnatomyDataset([records[i] for i in val_idx], train=False, **common)
    return train_ds, val_ds


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--model", required=True,
                    help="resnet50 | densenet121 | convnext_tiny | vit_small_patch16_224 | "
                         "stream_a | stream_b | always_on | second_opinion | arbiter")
    ap.add_argument("--folds", type=int, default=None)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--epochs", type=int, default=None)
    ap.add_argument("--limit", type=int, default=None, help="subsample dataset for a smoke test")
    ap.add_argument("--no-sweep", action="store_true")
    ap.add_argument("--ablate", nargs="*", default=None,
                    help="ARBITER ablations: no_film no_spatial no_l2 no_evid_input no_anat_input")
    args = ap.parse_args()

    cfg = load_config(args.config)
    run_name = args.model
    if args.ablate:
        cfg.setdefault("model", {})["ablate"] = list(args.ablate)
        run_name = f"{args.model}__{'+'.join(args.ablate)}"
        if "no_evid_input" in args.ablate:
            cfg.setdefault("loss", {})["w_evid"] = 0.0
    if args.epochs:
        cfg["train"]["epochs"] = args.epochs
    if args.limit:
        cfg["dataset"]["limit"] = args.limit
    seed = args.seed if args.seed is not None else cfg.get("seed", 42)
    n_folds = args.folds or cfg.get("folds", 5)
    out_root = Path(args.out or cfg.get("out_dir", "runs")) / cfg["dataset"]["name"] / run_name
    out_root.mkdir(parents=True, exist_ok=True)
    log = get_logger("arbiter", out_root / "train.log")

    set_seed(seed)
    device = get_device()
    log.info(f"device={device} model={args.model} dataset={cfg['dataset']['name']} folds={n_folds}")

    records, classes = build_dataset_records(cfg)
    num_classes = len(classes)
    log.info(f"{len(records)} images, {num_classes} classes: {classes}")

    folds = make_folds(records, n_folds, seed, cfg["dataset"].get("group_by_patient", False))
    fold_metrics, sweeps = [], []

    for f, (tr_idx, va_idx) in enumerate(folds):
        log.info(f"===== fold {f + 1}/{n_folds} =====")
        set_seed(seed + f)
        train_ds, val_ds = build_datasets(cfg, records, tr_idx, va_idx)
        train_loader, val_loader = make_loaders(train_ds, val_ds, cfg)

        model = build_model(args.model, num_classes, cfg.get("model", {})).to(device)
        cw = class_weights(train_ds.labels, num_classes) if cfg["train"].get("class_weight", True) else None

        fold_dir = out_root / f"fold{f}"
        fit(model, train_loader, val_loader, cfg, device, args.model, num_classes, cw, fold_dir)

        res = evaluate(model, val_loader, device, num_classes,
                       costs=cfg.get("costs", [0.400, 0.412, 0.855]))
        probs, y = res.pop("_probs"), res.pop("_y")
        levels = res.pop("_levels")
        res.pop("_idx", None)
        res.pop("_level_logits", None)
        np.savez_compressed(fold_dir / "preds.npz", probs=probs, y=y, levels=levels)
        res["ci_accuracy"] = bootstrap_ci(y, probs, num_classes, "accuracy", n_boot=500, seed=seed)["hi"]
        fold_metrics.append({k: v for k, v in res.items() if isinstance(v, (int, float))})
        save_json(res, fold_dir / "metrics.json")
        log.info(f"fold {f}: acc={res['accuracy']:.4f} auroc={res['auroc']:.4f} "
                 f"escalation={res.get('escalation_rate', 0):.3f} gflops={res.get('mean_gflops', 0):.3f}")

        if args.model == "arbiter" and not args.no_sweep:
            sweeps.append(budget_sweep(model, val_loader, device, num_classes,
                                       costs=cfg.get("costs", [0.400, 0.412, 0.855])))
        del model
        torch.cuda.empty_cache()

    summary = aggregate_folds(fold_metrics)
    save_json({"model": args.model, "dataset": cfg["dataset"]["name"], "classes": classes,
               "folds": fold_metrics, "summary": summary}, out_root / "summary.json")
    if sweeps:
        save_json(sweeps, out_root / "budget_sweep.json")

    # static cost report (per-path, matching the efficiency table)
    model = build_model(args.model, num_classes, cfg.get("model", {}))
    size = cfg["dataset"].get("size", 224)
    cost = {"params_m": count_params(model)}
    try:
        if args.model in ("arbiter", "always_on", "second_opinion"):
            cost["gflops_full"] = count_flops(model, [(3, size, size), (3, size, size), (1, size, size)])
        else:
            cost["gflops_full"] = count_flops(model, [(3, size, size), (3, size, size), (1, size, size)])
    except Exception as e:  # profiling must never break a run
        cost["gflops_full"] = 0.0
        cost["flops_error"] = str(e)
    save_json(cost, out_root / "cost.json")

    log.info("=" * 60)
    for k in ("accuracy", "precision", "recall", "specificity", "f1", "f1_rs", "auroc",
              "ece", "escalation_rate", "mean_gflops"):
        if k in summary:
            log.info(f"{k:>16}: {summary[k]['mean']:.4f} ± {summary[k]['ci95']:.4f}")


if __name__ == "__main__":
    main()
