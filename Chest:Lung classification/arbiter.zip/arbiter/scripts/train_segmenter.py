#!/usr/bin/env python3
"""Train the anatomy segmenter (U-Net, MiT-B0 encoder).

FracAtlas: run scripts/export_fracatlas_masks.py first to rasterise the COCO
polygons, then train here on the annotated subset.
COVID-19 Radiography: lung masks ship with the dataset, so point --masks at them.

The trained checkpoint is consumed by scripts/precompute_masks.py, which writes
one predicted mask per image for the whole corpus.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from arbiter.data.masks import load_gray, load_mask  # noqa: E402
from arbiter.models.segmenter import DiceBCELoss, build_segmenter, dice_score  # noqa: E402
from arbiter.utils import get_device, get_logger, set_seed  # noqa: E402


class SegDataset(Dataset):
    def __init__(self, pairs, size=224, train=True):
        self.pairs = pairs
        self.size = size
        self.train = train

    def __len__(self):
        return len(self.pairs)

    def __getitem__(self, i):
        ip, mp = self.pairs[i]
        img = load_gray(ip, self.size)
        msk = load_mask(mp, self.size)
        x = torch.from_numpy(img).unsqueeze(0)
        y = torch.from_numpy(msk).unsqueeze(0)
        if self.train and np.random.rand() < 0.5:
            x, y = torch.flip(x, [-1]), torch.flip(y, [-1])
        return x, y


def collect_pairs(images_dir: Path, masks_dir: Path):
    masks = {p.stem: p for p in list(masks_dir.glob("*.png")) + list(masks_dir.glob("*.jpg"))}
    pairs = []
    for p in list(images_dir.rglob("*.jpg")) + list(images_dir.rglob("*.png")):
        m = masks.get(p.stem)
        if m is not None:
            pairs.append((str(p), str(m)))
    return pairs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", required=True)
    ap.add_argument("--masks", required=True)
    ap.add_argument("--out", default="runs/segmenter")
    ap.add_argument("--encoder", default="mit_b0")
    ap.add_argument("--epochs", type=int, default=30)
    ap.add_argument("--batch-size", type=int, default=16)
    ap.add_argument("--lr", type=float, default=3e-4)
    ap.add_argument("--size", type=int, default=224)
    ap.add_argument("--val-frac", type=float, default=0.15)
    args = ap.parse_args()

    set_seed(42)
    device = get_device()
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    log = get_logger("segmenter", out / "train.log")

    pairs = collect_pairs(Path(args.images), Path(args.masks))
    if not pairs:
        raise SystemExit("No (image, mask) pairs found — check --images / --masks")
    rng = np.random.default_rng(42)
    perm = rng.permutation(len(pairs))
    n_val = max(int(len(pairs) * args.val_frac), 1)
    val_pairs = [pairs[i] for i in perm[:n_val]]
    train_pairs = [pairs[i] for i in perm[n_val:]]
    log.info(f"{len(train_pairs)} train / {len(val_pairs)} val mask pairs")

    tl = DataLoader(SegDataset(train_pairs, args.size, True), batch_size=args.batch_size,
                    shuffle=True, num_workers=2, drop_last=True)
    vl = DataLoader(SegDataset(val_pairs, args.size, False), batch_size=args.batch_size, num_workers=2)

    model = build_segmenter(args.encoder, in_ch=1).to(device)
    crit = DiceBCELoss()
    opt = torch.optim.AdamW(model.parameters(), lr=args.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=args.epochs)

    best = -1.0
    for ep in range(args.epochs):
        model.train()
        tot = 0.0
        for x, y in tl:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            loss = crit(model(x), y)
            loss.backward()
            opt.step()
            tot += float(loss) * x.size(0)
        sched.step()

        model.eval()
        dices = []
        with torch.no_grad():
            for x, y in vl:
                x, y = x.to(device), y.to(device)
                dices.append(dice_score(model(x), y))
        d = float(np.mean(dices)) if dices else 0.0
        log.info(f"ep {ep+1}/{args.epochs} loss={tot/max(len(tl.dataset),1):.4f} val_dice={d:.4f}")
        if d > best:
            best = d
            torch.save({"state_dict": model.state_dict(), "encoder": args.encoder,
                        "size": args.size, "dice": d}, out / "segmenter.pt")
    log.info(f"best val dice = {best:.4f} -> {out/'segmenter.pt'}")


if __name__ == "__main__":
    main()
