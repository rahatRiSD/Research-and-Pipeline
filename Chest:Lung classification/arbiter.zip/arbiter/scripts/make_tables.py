#!/usr/bin/env python3
"""Build the five paper tables from runs/ into LaTeX + CSV.

  Table 1  Main results, fracture dataset (FracAtlas)
  Table 2  Main results, chest dataset (ChestX-ray14 subset)
  Table 3  Efficiency and routing behaviour (params, GFLOPs, level mix, regret)
  Table 4  Ablation of ARBITER components
  Table 5  Calibration and XAI faithfulness
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Dict, List, Optional

DISPLAY = {
    "resnet50": "ResNet-50",
    "densenet121": "DenseNet-121 (CheXNet-style)",
    "convnext_tiny": "ConvNeXt-T",
    "vit_small_patch16_224": "ViT-S/16",
    "stream_a": "Stream A only",
    "stream_b": "Stream B only (anatomy)",
    "always_on": "Always-On dual-stream",
    "second_opinion": "SecondOpinion (prior SOTA)",
    "arbiter": "\\textbf{ARBITER (ours)}",
}

MAIN_COLS = [("accuracy", "Acc."), ("precision", "Prec."), ("recall", "Rec."),
             ("specificity", "Spec."), ("f1", "F1"), ("auroc", "AUROC")]
EFF_COLS = [("params_m", "Params (M)"), ("mean_gflops", "GFLOPs"),
            ("frac_level1", "L1 %"), ("frac_level2", "L2 %"), ("frac_level3", "L3 %"),
            ("escalation_rate", "Escal."), ("router_agreement", "Router agr."),
            ("routing_regret", "Regret"), ("accuracy", "Acc.")]
CAL_COLS = [("ece", "ECE"), ("brier", "Brier"), ("deletion_auc", "Del. AUC"),
            ("insertion_auc", "Ins. AUC"), ("pointing_game", "Pointing"),
            ("mask_energy", "Mask energy")]


def load_runs(runs_dir: Path) -> Dict[str, Dict[str, dict]]:
    """{dataset: {model: summary}}"""
    out: Dict[str, Dict[str, dict]] = {}
    for summ in runs_dir.rglob("summary.json"):
        model = summ.parent.name
        dataset = summ.parent.parent.name
        data = json.loads(summ.read_text())
        cost_path = summ.parent / "cost.json"
        if cost_path.exists():
            data["cost"] = json.loads(cost_path.read_text())
        xai_path = summ.parent / "xai_metrics.json"
        if xai_path.exists():
            data["xai"] = json.loads(xai_path.read_text())
        out.setdefault(dataset, {})[model] = data
    return out


def _val(summary: dict, key: str) -> Optional[tuple]:
    s = summary.get("summary", {})
    if key in s:
        return s[key]["mean"], s[key]["ci95"]
    for extra in ("cost", "xai"):
        if key in summary.get(extra, {}):
            return summary[extra][key], 0.0
    return None


def fmt(v: Optional[tuple], pct: bool = False, dec: int = 3) -> str:
    if v is None:
        return "--"
    m, ci = v
    if pct:
        return f"{m*100:.2f}\\% $\\pm$ {ci*100:.2f}" if ci else f"{m*100:.2f}\\%"
    return f"{m:.{dec}f} $\\pm$ {ci:.{dec}f}" if ci else f"{m:.{dec}f}"


def write_table(path_stem: Path, caption: str, label: str, header: List[str],
                rows: List[List[str]]) -> None:
    path_stem.parent.mkdir(parents=True, exist_ok=True)
    with open(path_stem.with_suffix(".csv"), "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows([[c.replace("\\%", "%").replace("$\\pm$", "+-").replace("\\textbf{", "").replace("}", "")
                      for c in r] for r in rows])
    lines = [
        "\\begin{table}[t]", "\\centering", f"\\caption{{{caption}}}", f"\\label{{{label}}}",
        "\\resizebox{\\textwidth}{!}{%",
        "\\begin{tabular}{l" + "c" * (len(header) - 1) + "}", "\\hline",
        " & ".join(header) + " \\\\", "\\hline",
    ]
    lines += [" & ".join(r) + " \\\\" for r in rows]
    lines += ["\\hline", "\\end{tabular}}", "\\end{table}", ""]
    path_stem.with_suffix(".tex").write_text("\n".join(lines))
    print(f"wrote {path_stem.with_suffix('.tex')} and .csv")


def main_table(runs: Dict[str, dict], out: Path, dataset: str, caption: str, label: str,
               order: List[str], extra_f1rs: bool = False) -> None:
    cols = MAIN_COLS + ([("f1_rs", "F1$_{R/S}$")] if extra_f1rs else [])
    header = ["Method"] + [c[1] for c in cols]
    rows = []
    for m in order:
        if m not in runs:
            continue
        s = runs[m]
        row = [DISPLAY.get(m, m)]
        for key, _ in cols:
            pct = key in ("accuracy", "precision", "recall", "specificity")
            row.append(fmt(_val(s, key), pct=pct))
        rows.append(row)
    write_table(out, caption, label, header, rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="paper/tables")
    args = ap.parse_args()
    runs_dir, out_dir = Path(args.runs), Path(args.out)
    all_runs = load_runs(runs_dir)
    if not all_runs:
        raise SystemExit(f"no summary.json under {runs_dir}")

    order = list(DISPLAY.keys())
    datasets = sorted(all_runs.keys())
    frac = next((d for d in datasets if "frac" in d), datasets[0])
    chest = next((d for d in datasets if d != frac), None)

    # Table 1 / 2 -------------------------------------------------------- #
    main_table(all_runs[frac], out_dir / "table1_fracture", frac,
               f"Fracture classification results on {frac} (mean over 5-fold CV, 95\\% CI). "
               "F1$_{R/S}$ is the harmonic mean of recall and specificity, following the "
               "fracture-detection convention.",
               "tab:fracture", order, extra_f1rs=True)
    if chest:
        main_table(all_runs[chest], out_dir / "table2_chest", chest,
                   f"Chest radiograph classification results on {chest} "
                   "(mean over 5-fold CV, 95\\% CI).", "tab:chest", order)

    # Table 3: efficiency + routing --------------------------------------- #
    header = ["Method", "Dataset"] + [c[1] for c in EFF_COLS]
    rows = []
    for ds in datasets:
        for m in order:
            if m not in all_runs[ds]:
                continue
            s = all_runs[ds][m]
            row = [DISPLAY.get(m, m), ds]
            for key, _ in EFF_COLS:
                pct = key.startswith("frac_level") or key in ("escalation_rate", "accuracy",
                                                              "router_agreement")
                row.append(fmt(_val(s, key), pct=pct))
            rows.append(row)
    write_table(out_dir / "table3_efficiency",
                "Computational cost and routing behaviour. Level shares are the fraction of test "
                "cases resolved at each rung of the cascade; regret is the accuracy gap to an "
                "oracle router that always picks the cheapest correct level.",
                "tab:efficiency", header, rows)

    # Table 4: ablations --------------------------------------------------- #
    rows = []
    for ds in datasets:
        for m in sorted(all_runs[ds]):
            if not m.startswith("arbiter"):
                continue
            s = all_runs[ds][m]
            name = "Full model" if m == "arbiter" else "-- " + m.split("__", 1)[1].replace("+", ", ")
            rows.append([name, ds,
                         fmt(_val(s, "accuracy"), pct=True), fmt(_val(s, "auroc")),
                         fmt(_val(s, "f1")), fmt(_val(s, "mean_gflops")),
                         fmt(_val(s, "escalation_rate"), pct=True),
                         fmt(_val(s, "routing_regret"))])
    if rows:
        write_table(out_dir / "table4_ablation",
                    "Ablation of ARBITER components. Removing the level-2 rung (no\\_l2) reduces "
                    "the model to binary gating; removing FiLM or the spatial gate strips the "
                    "cheap anatomical conditioning; the router-input ablations test what the "
                    "escalation decision actually relies on.",
                    "tab:ablation",
                    ["Variant", "Dataset", "Acc.", "AUROC", "F1", "GFLOPs", "Escal.", "Regret"], rows)

    # Table 5: calibration + XAI faithfulness ------------------------------ #
    header = ["Method", "Dataset"] + [c[1] for c in CAL_COLS]
    rows = []
    for ds in datasets:
        for m in order:
            if m not in all_runs[ds]:
                continue
            s = all_runs[ds][m]
            row = [DISPLAY.get(m, m), ds]
            for key, _ in CAL_COLS:
                row.append(fmt(_val(s, key)))
            if any(c != "--" for c in row[2:]):
                rows.append(row)
    write_table(out_dir / "table5_calibration_xai",
                "Calibration and explanation faithfulness. Deletion AUC is lower-is-better, "
                "insertion AUC higher-is-better; pointing game and mask energy measure how much "
                "of the saliency falls on anatomy rather than on background or image artefacts.",
                "tab:calibration", header, rows)


if __name__ == "__main__":
    main()
