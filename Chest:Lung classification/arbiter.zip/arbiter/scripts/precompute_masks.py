#!/usr/bin/env python3
"""Run the trained segmenter over every image and cache predicted masks.

Downstream classifiers always read these *predicted* masks (train and test
alike), so anatomy annotations never leak into the classification results.

Also provides --export-fracatlas-coco to rasterise FracAtlas COCO polygons into
the PNG masks that train_segmenter.py consumes.
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import numpy as np
import torch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from arbiter.data.fracatlas import export_coco_masks  # noqa: E402
from arbiter.data.masks import load_gray, otsu_anatomy_mask, save_mask  # noqa: E402
from arbiter.models.segmenter import build_segmenter  # noqa: E402
from arbiter.utils import get_device, get_logger  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--images", help="root folder scanned recursively for images")
    ap.add_argument("--ckpt", help="segmenter checkpoint from train_segmenter.py")
    ap.add_argument("--out", default="data/masks_pred")
    ap.add_argument("--size", type=int, default=224)
    ap.add_argument("--thr", type=float, default=0.5)
    ap.add_argument("--batch-size", type=int, default=32)
    ap.add_argument("--fallback", default="bone", choices=["bone", "lung", "none"],
                    help="Otsu fallback when no checkpoint is given")
    ap.add_argument("--export-fracatlas-coco", metavar="FRACATLAS_ROOT",
                    help="rasterise COCO polygons to PNG masks and exit")
    args = ap.parse_args()

    log = get_logger("masks")

    if args.export_fracatlas_coco:
        n = export_coco_masks(args.export_fracatlas_coco, args.out, args.size)
        log.info(f"wrote {n} COCO-derived masks to {args.out}")
        return

    if not args.images:
        raise SystemExit("--images is required")

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    paths = sorted([p for p in Path(args.images).rglob("*")
                    if p.suffix.lower() in {".png", ".jpg", ".jpeg"}])
    log.info(f"{len(paths)} images -> {out}")

    if args.ckpt:
        device = get_device()
        ck = torch.load(args.ckpt, map_location=device)
        model = build_segmenter(ck.get("encoder", "mit_b0"), in_ch=1, pretrained=False).to(device)
        model.load_state_dict(ck["state_dict"])
        model.eval()
        buf, names = [], []
        with torch.no_grad():
            for i, p in enumerate(paths):
                buf.append(load_gray(p, args.size))
                names.append(p.stem)
                if len(buf) == args.batch_size or i == len(paths) - 1:
                    x = torch.from_numpy(np.stack(buf)).unsqueeze(1).to(device)
                    pr = torch.sigmoid(model(x)).cpu().numpy()[:, 0]
                    for nm, m in zip(names, pr):
                        save_mask((m > args.thr).astype(np.float32), out / f"{nm}.png")
                    buf, names = [], []
                if i % 500 == 0:
                    log.info(f"  {i}/{len(paths)}")
    else:
        log.info(f"no checkpoint given; using Otsu '{args.fallback}' fallback")
        for i, p in enumerate(paths):
            g = load_gray(p, args.size)
            m = otsu_anatomy_mask(g, modality=args.fallback)
            save_mask(m, out / f"{p.stem}.png")
            if i % 500 == 0:
                log.info(f"  {i}/{len(paths)}")
    log.info("done")


if __name__ == "__main__":
    main()
