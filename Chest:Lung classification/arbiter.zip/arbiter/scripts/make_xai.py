#!/usr/bin/env python3
"""Figure 4 (qualitative XAI panel) + the faithfulness numbers used in Table 5.

For a routed model the interesting comparison is *within* a case: the level-1
CAM shows what the cheap pathway looked at, the level-2/3 CAM shows what changed
once anatomy was consulted, the cross-attention map shows where in the anatomy
stream the primary stream searched, and the router attribution says which piece
of evidence triggered the escalation in the first place.

    python scripts/make_xai.py --config configs/fracatlas.yaml --runs runs
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import torch  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from arbiter.data import AnatomyDataset, build_dataset_records, make_folds  # noqa: E402
from arbiter.data.transforms import denormalize_rgb  # noqa: E402
from arbiter.models import build_model  # noqa: E402
from arbiter.utils import get_device, get_logger, load_config, save_json  # noqa: E402
from arbiter.xai import (cross_attention_map, deletion_insertion_auc, grad_cam,  # noqa: E402
                         mask_energy_ratio, overlay, pointing_game,
                         resolve_target_layer, router_attribution)

plt.rcParams.update({"figure.dpi": 160, "savefig.dpi": 300, "font.size": 8,
                     "savefig.bbox": "tight"})


def load_trained(model_name: str, cfg, num_classes: int, runs: Path, dataset: str, fold: int, device):
    model = build_model(model_name, num_classes, cfg.get("model", {})).to(device)
    w = runs / dataset / model_name / f"fold{fold}" / "weights.pt"
    if w.exists():
        model.load_state_dict(torch.load(w, map_location=device))
    else:
        print(f"  !! no weights at {w}; using an untrained model (smoke-test mode)")
    model.eval()
    return model


def cam_for_level(model, x_a, x_b, mask, cls, level: int):
    """CAM on the feature map that the chosen level actually classifies."""
    if level == 1:
        layer = resolve_target_layer(model, "a")

        def fwd():
            return model.forward_level1(x_a)["z1"]
    elif level == 2:
        layer = resolve_target_layer(model, "a")

        def fwd():
            st = model.forward_level1(x_a)
            return model.forward_level2(st, mask)["z2"]
    else:
        layer = resolve_target_layer(model, "b")

        def fwd():
            st = model.forward_level1(x_a)
            st = model.forward_level2(st, mask)
            return model.forward_level3(st, x_b)["z3"]
    return grad_cam(model, layer, fwd, cls, size=x_a.shape[-2:], variant="gradcam++")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--runs", default="runs")
    ap.add_argument("--out", default="paper/figures")
    ap.add_argument("--model", default="arbiter")
    ap.add_argument("--fold", type=int, default=0)
    ap.add_argument("--n-cases", type=int, default=4)
    ap.add_argument("--faithfulness-n", type=int, default=128)
    args = ap.parse_args()

    cfg = load_config(args.config)
    dataset = cfg["dataset"]["name"]
    runs = Path(args.runs)
    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)
    log = get_logger("xai")
    device = get_device()

    records, classes = build_dataset_records(cfg)
    num_classes = len(classes)
    folds = make_folds(records, cfg.get("folds", 5), cfg.get("seed", 42),
                       cfg["dataset"].get("group_by_patient", False))
    _, va_idx = folds[args.fold]
    a = cfg.get("anatomy", {})
    ds = AnatomyDataset([records[i] for i in va_idx], size=cfg["dataset"].get("size", 224),
                        train=False, anatomy_source=a.get("source", "otsu"),
                        anatomy_modality=a.get("modality", "bone"),
                        compose_mode=a.get("compose", "soft"), mask_root=a.get("mask_root"))
    loader = torch.utils.data.DataLoader(ds, batch_size=16, shuffle=False, num_workers=2)

    model = load_trained(args.model, cfg, num_classes, runs, dataset, args.fold, device)

    # ------------------------------------------------------------------ #
    # 1. Faithfulness metrics over a sample of the validation fold
    # ------------------------------------------------------------------ #
    del_aucs, ins_aucs, points, energies, attribs = [], [], [], [], []
    seen = 0
    for batch in loader:
        x_a = batch["x_a"].to(device)
        x_b = batch["x_b"].to(device)
        mask = batch["mask"].to(device)
        with torch.no_grad():
            out_i = model.infer(x_a, x_b, mask) if hasattr(model, "infer") else model(x_a, x_b, mask)
        cls = out_i["logits"].argmax(1)

        if hasattr(model, "forward_level1"):
            cam = cam_for_level(model, x_a, x_b, mask, cls, 1)

            def fwd_fn(x):
                return model.forward_level1(x)["z1"]
        else:
            layer = resolve_target_layer(model, "a")
            cam = grad_cam(model, layer, lambda: model(x_a, x_b, mask)["logits"], cls,
                           size=x_a.shape[-2:], variant="gradcam++")

            def fwd_fn(x):
                return model(x, x_b, mask)["logits"]

        del_aucs.append(deletion_insertion_auc(fwd_fn, x_a, cam, cls, mode="deletion"))
        ins_aucs.append(deletion_insertion_auc(fwd_fn, x_a, cam, cls, mode="insertion"))
        m_np = mask.squeeze(1).cpu().numpy()
        points.append(pointing_game(cam, m_np))
        energies.append(mask_energy_ratio(cam, m_np))
        if hasattr(model, "router"):
            attribs.append(router_attribution(model, x_a, x_b, mask, level=2))

        seen += x_a.shape[0]
        if seen >= args.faithfulness_n:
            break

    metrics = {
        "deletion_auc": float(np.concatenate(del_aucs).mean()),
        "insertion_auc": float(np.concatenate(ins_aucs).mean()),
        "pointing_game": float(np.concatenate(points).mean()),
        "mask_energy": float(np.concatenate(energies).mean()),
        "n_cases": int(seen),
    }
    if attribs:
        keys = attribs[0].keys()
        metrics["router_attribution"] = {
            k: float(np.abs(np.concatenate([a_[k] for a_ in attribs])).mean()) for k in keys
        }
    save_json(metrics, runs / dataset / args.model / "xai_metrics.json")
    log.info(f"faithfulness: {metrics}")

    # ------------------------------------------------------------------ #
    # 2. Figure 4: per-case panel, prioritising escalated cases
    # ------------------------------------------------------------------ #
    if not hasattr(model, "forward_level1"):
        log.info("model has no cascade; skipping Figure 4")
        return

    chosen = []
    for batch in loader:
        x_a = batch["x_a"].to(device)
        x_b = batch["x_b"].to(device)
        mask = batch["mask"].to(device)
        with torch.no_grad():
            oi = model.infer(x_a, x_b, mask)
        lv = oi["level"].cpu().numpy()
        correct = (oi["logits"].argmax(1).cpu() == batch["y"]).numpy()
        for i in range(len(lv)):
            if len(chosen) >= args.n_cases:
                break
            want_deep = sum(1 for c in chosen if c["level"] >= 2)
            if (lv[i] >= 2 and want_deep < args.n_cases - 1 and correct[i]) or \
               (lv[i] == 1 and want_deep >= 1 and correct[i] and
                    not any(c["level"] == 1 for c in chosen)):
                chosen.append({"x_a": x_a[i:i + 1], "x_b": x_b[i:i + 1], "mask": mask[i:i + 1],
                               "y": int(batch["y"][i]), "level": int(lv[i]),
                               "cls": oi["logits"][i:i + 1].argmax(1)})
        if len(chosen) >= args.n_cases:
            break

    if not chosen:
        log.info("no cases selected for Figure 4")
        return

    ncol = 5
    fig, axes = plt.subplots(len(chosen), ncol, figsize=(2.35 * ncol, 2.35 * len(chosen)),
                             squeeze=False)
    for r, c in enumerate(chosen):
        gray = denormalize_rgb(c["x_a"][0]).mean(0).cpu().numpy()
        m = c["mask"][0, 0].cpu().numpy()
        cam1 = cam_for_level(model, c["x_a"], c["x_b"], c["mask"], c["cls"], 1)[0]
        deep = max(c["level"], 2)
        cam_deep = cam_for_level(model, c["x_a"], c["x_b"], c["mask"], c["cls"], deep)[0]

        with torch.no_grad():
            st = model.forward_level1(c["x_a"])
            st = model.forward_level2(st, c["mask"])
            st = model.forward_level3(st, c["x_b"])
        attn = cross_attention_map(model.fusion, size=gray.shape)
        attn = attn[0] if attn is not None else np.zeros_like(gray)

        panels = [
            (gray, f"{classes[c['y']]} | routed to L{c['level']}", "gray"),
            (m, "anatomy mask", "gray"),
            (overlay(cam1, gray), "Grad-CAM++ level 1", None),
            (overlay(cam_deep, gray), f"Grad-CAM++ level {deep}", None),
            (overlay(attn, gray), "cross-attention (L3)", None),
        ]
        for j, (img, title, cmap) in enumerate(panels):
            ax = axes[r][j]
            ax.imshow(img, cmap=cmap)
            ax.set_title(title, fontsize=7.5)
            ax.axis("off")

        if hasattr(model, "router"):
            att = router_attribution(model, c["x_a"], c["x_b"], c["mask"], level=2)
            top = sorted(att.items(), key=lambda kv: -abs(float(kv[1][0])))[:2]
            axes[r][0].set_xlabel("")
            axes[r][0].text(0.02, 0.02,
                            "router: " + ", ".join(f"{k} {float(v[0]):+.2f}" for k, v in top),
                            transform=axes[r][0].transAxes, fontsize=6, color="yellow")

    fig.suptitle("Figure 4 — what anatomical escalation changes, per case", fontsize=10)
    fig.tight_layout()
    fig.savefig(out / f"fig4_xai_{dataset}.png")
    fig.savefig(out / f"fig4_xai_{dataset}.pdf")
    plt.close(fig)
    log.info(f"wrote {out / f'fig4_xai_{dataset}.png'}")


if __name__ == "__main__":
    main()
