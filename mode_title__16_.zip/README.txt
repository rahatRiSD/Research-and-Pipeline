NCTBench manuscript - LaTeX project
COMPILE: xelatex main.tex (run twice). Needs the font "Noto Sans Bengali".
  Bibliography is embedded (thebibliography); references.bib is kept in sync for reference.
  pdfLaTeX path needs bn_all.pdf (not included); the 22 \bn{} strings are unchanged in number/order only if none were added.
BLIND REVIEW: class option 'doubleblind' hides the template author footer. For the final version
  remove it and add \author / \affiliation blocks.
HIGHLIGHT: \showrevisionsfalse in main.tex; \rev{} text prints normally; \showrevisionstrue gives blue highlights.
FIGURES: Fig1_ResearchGap.png, Fig2_Workflow.png (repainted), Diagram_V2.png (unchanged), fig4_tradeoff.pdf (new Figure 4).
